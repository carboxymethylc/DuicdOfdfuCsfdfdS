/** Automatically generated file. DO NOT MODIFY */
package com.crossdial.henapad_paid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}