﻿/*
 * Created by z on 2010/11/09.
 * Modified by z.c. on 2010/10 - 2012/03.
 * Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 */

package com.crossdial.henapad_paid;

import android.util.Log;

public class Logx 
{
	static public boolean DEVICE = true;//false;
	static public boolean DEBUG = false;//true;//false;
	static public StringBuilder logs = new StringBuilder(1024);
	
	static public long startTime = 0;
	
	static public double getPastTime()
	{
		if(logs.length() > 102400)
			logs.setLength(0);
		
		if(startTime == 0)
		{
			startTime = System.currentTimeMillis();
			return 0;
		}
		long curTime = System.currentTimeMillis();
		return ((double)(curTime - startTime))/1000.0;
		
	}
	static public void d(String a, String b)
	{
		if(!DEBUG) return;
		logs.append(String.format("\n%03.3f:%s\n%s", getPastTime(), a, b));
		if(!DEVICE)
			Log.d(a,b);
		return;
	}
	static public void e(String a, String b)
	{
		if(!DEBUG) return;
		logs.append(String.format("\n%03.3f:%s\n%s", getPastTime(), a, b));
		if(!DEVICE)
			Log.e(a,b);
		return;
	}
	static public void i(String a, String b)
	{
		if(!DEBUG) return;
		logs.append(String.format("\n%03.3f:%s\n%s", getPastTime(), a, b));
		if(!DEVICE)
			Log.i(a,b);
		return;
	}
	
}
