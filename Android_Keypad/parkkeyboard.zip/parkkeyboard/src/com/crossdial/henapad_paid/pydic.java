﻿/*******************************************************
* HanWJ_PinYin Module
* Copyright (C) 2P Technologies,Inc. All rights reserved.
*
* This software is the confidential and proprietary information
* of 2P Technologies,Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered
* into with 2P Technologies,Inc.
*
* This HanWJ_PinYin module is a subset of HanWJ Chinese Input Technologies.
* For details, please see www.HanWJ.com and www.TypingChinese.com.
********************************************************/
package com.crossdial.henapad_paid;
import com.crossdial.henapad_paid.R;

import java.util.ArrayList;

import android.content.Context;

//#import "pydic.h"
/*
String *replaceSigns(String* src, String* sign, String* dst);

boolean InitKey2ChsDicPY();
boolean BuildIdx2KeysInDic();

boolean Load1KeyPyDic();

short GetArrPosForIndexVal(LPCTSTR szKey);
boolean LookupExactHelper(String* strKeySeq0, NSMutableString *arrChars);
*/

public class pydic {
	
	Context m_context = null;
	public pydic(Context context)
	{
		m_context = context;
		initChinese();
	}
	
	final int MAXPYLEN = 32;
	// 대역변수들.
	int			[]idx2KeysInDic;//[50][50]
	
	byte			[]m_pDic;
	String			m_pGbk;//py gbk. m_pDic[1] has <pinyin, index_into_m_pGbk> pairs, where index_into_m_pGbk in index into m_pGbk which is a simple flat list of chn chars grouped by pinyin.
	//i.e., m_pDic has no chn chars, they are all in m_pGbk which is a image of gbkflat.dic. If need to adjust fix-order or add/delete chn chars, do it in this file.
	int				m_PyDanZiChnStep;
	
	String[]	m_str1KeyPyDic = new String['z'-'a'+1];//b-z
	
	boolean			m_bInitDone;
	
	int  min(int a, int b) {return (a)>(b)?(b):(a);}
	int  max(int a, int b) {return (a)<(b)?(b):(a);}
	
	
	short GetKeyOrdinalNum(short k)
	{
		int pos;
		if(95 < k)
			pos = k - 73;
		else if(93 == k)
			pos = 22;
		else if(91 == k)
			pos = 21;
		else if(64 == k)
			pos = 20;
		else if(61 == k)
			pos = 19;
		else if(59 == k)
			pos = 18;
		else if(43 < k)
			pos = k - 40;
		else if(39 == k)
			pos = 3;
		else if(34 < k)
			pos = k - 34;
		else //if(33 == k or 0 == k)
			pos = 0;
		pos = max(0, (min(49, pos) ) );
		return (short)pos;
	}
	
	short GetArrPosForIndexVal(short []szKey)
	{
		short m,n;
		m = GetKeyOrdinalNum(szKey[0]);
		if(szKey.length > 1 )
			n = GetKeyOrdinalNum(szKey[1]);
		else 
			n = 0;
		//NSLog(@">>> GetArrPosForIndexVal m=%d, n=%d r = %d", m, n,m*50+n);
		return (short)(m*50+n);
	}
	
	
	
	void CPyDictionary()
	{
		m_bInitDone = false;
	}
	
	void _CPyDictionary()
	{
		m_pDic = null;
		m_pGbk = null;
		idx2KeysInDic = null;
	}
	
	void InitFirst()
	{
		if(m_bInitDone)
			return;
		
		m_pGbk = null;
		m_pDic = null;
		idx2KeysInDic = null;
		
		m_PyDanZiChnStep = 1;
		
	}
	
	
	void InitDictionary()
	{
		InitKey2ChsDicPY();
		
		Load1KeyPyDic();
		
		m_bInitDone = true;
	}
	
	void CloseDictionary()
	{
		if(idx2KeysInDic != null)
		{
			idx2KeysInDic = null;
		}
		if (m_pDic != null)
		{
			m_pDic = null;
		}
		m_bInitDone = false;
	}
	
	
	boolean BuildIdx2KeysInDic()
	{
		int idxsize = 50*50;
		short []szKey = new short[512];
		short []old = new short[2];
		int k, i = 0;
		short arrPosForIndexVal;
		old[0] = old[1] = 0;
		int chnstep = 4;
		byte []pDic;
		
		if(idx2KeysInDic == null)
			idx2KeysInDic = new int[(idxsize+32)];// new int[idxsize+32];
		
		pDic = m_pDic;
		
		for(i = 0; i < idx2KeysInDic.length; i++)
		{
			idx2KeysInDic[i] = 0;;
		}
		
		if(pDic == null)
			return false;
		i = 0;
		while(i < pDic.length && pDic[i] != 0 )
		{

			//get key
			k = 0;
			while( pDic[i] != 0 && (pDic[i] & 0x80) == 0 )
			{

				szKey[k] = pDic[i];
				k++; i++;
			}
			szKey[k] = 0;
			if(1 == k)
			{
				arrPosForIndexVal = GetArrPosForIndexVal(szKey);
				idx2KeysInDic[arrPosForIndexVal] = i-k;
				old[0] = szKey[0];
				old[1] = '!';//"a!" starts from same pos as "a"
			}
			else if(szKey[0] > old[0] || szKey[1] > old[1])
			{
				arrPosForIndexVal = GetArrPosForIndexVal(szKey);
				idx2KeysInDic[arrPosForIndexVal] = i-k;
				old[0] = szKey[0];
				old[1] = szKey[1];
			}
			else {
				//A problem! 2011.1.31 zc. 
				String str;
				str = String.format("!!error i = %d : %d,%d %d, %d", i, szKey[0], old[0] , szKey[1], old[1]);
				Logx.e("error", str);
			}
			
			//pass chars
			while(i < pDic.length && (pDic[i] & 0x80) != 0 )//chn char
			{
				i+= chnstep;
			}
		}
		//make indexes mono increasing(fill out missing holes)
		for(i=0; i<idxsize-1; i++)
		{
//A problem! 2011.1.31 zc.		if(idx2KeysInDic[i+1] < idx2KeysInDic[i])
			if(idx2KeysInDic[i+1] == 0)
			{
				//NSLog(@"!!! sidx2KeysInDic[%d] = %d, [%d] = %d",i+1, idx2KeysInDic[i+1], i, idx2KeysInDic[i]);
				idx2KeysInDic[i+1] = idx2KeysInDic[i];
			}
		}
		return true;
	}
	
	public boolean GetCandidates(String keySequence, ArrayList<String> candidates)
	{
		String strKeySeq;
		strKeySeq = keySequence.toLowerCase();
		boolean bRet;
		int nLen;
		
		if(strKeySeq.length() > MAXPYLEN) {
			strKeySeq = strKeySeq.substring(0, MAXPYLEN);
		}
		nLen = strKeySeq.length();//.GetLength();
		
		int c0 = strKeySeq.charAt(0);
		if(1 == nLen && 'a' <= c0 && 'z' >= c0)
		{
			//py single char
			int index  = c0-'a';
			
			int len  =  m_str1KeyPyDic[index].length();
			if( len > 0 )
			{
				candidates.add(m_str1KeyPyDic[index]);
				return true;
			}
		}
		
		bRet = LookupExactHelper(strKeySeq, candidates);
		
		return bRet;
	}
	
	boolean LookupExactHelper(String strKeySeq0, ArrayList<String> arrChars)
	{
		String strKeySeq = strKeySeq0;
		short []pattern;// = (LPTSTR)(LPCTSTR)strKeySeq;
		int _len = strKeySeq.length();//.GetLength();
		pattern = new short[_len];
		for(int i = 0; i < _len; i++)
		{
			pattern[i] = (short)strKeySeq.charAt(i);
			if( !Character.isLowerCase(pattern[i]) )
				return false;
		}
		
		//now traverse char map;
		int i, iDic = 0;
		int k1, k2;//section in key to be compared
		int lenK;
		boolean match = false;
		int noMoreCompare = 0;
		//arrChars.RemoveAll();
		short arrPosForIndexVal = GetArrPosForIndexVal(pattern);
		byte []pDic;
//		int chnstep;
		
		pDic           = m_pDic;
//		chnstep = m_PyDanZiChnStep;
		if(idx2KeysInDic != null)
			iDic = idx2KeysInDic[(int)arrPosForIndexVal];
		//NSLog(@"iDic = %d, idx2KeysInDic[100] = %d", iDic, idx2KeysInDic[100]);
		
		if(pDic == null)
			return false;
		
		
//	union{
//		short wd;
//		byte b[2];
//	} u, u2;
		int u = 0, u2 = 0;
//		int index;
		match = false;
//		int preiDic = iDic;
		while(!match && pDic[iDic] != 0 && noMoreCompare == 0)
		{
			//get key
			k1 = iDic;
			while(pDic[iDic] != 0 && (pDic[iDic] & 0x80) == 0)
				iDic++;
			k2 = iDic;
			lenK = k2 - k1;
			if(_len == lenK)
			{//compare to pattern: [k1, k2) is key to be compared
				for (i=0;i<lenK;i++)
				{
					if(pattern[i] < pDic[k1+i])
					{
						noMoreCompare = 1;//keys is sorted!
						break;
					}
					else if(pattern[i] > pDic[k1+i])
						break;
				}
				if(i == lenK)
				{
					match = true;
					u = ((pDic[iDic] & 0x7f) << 8) + (pDic[iDic+1] & 0xFF); //?? zc
//				u.b[0] = pDic[iDic+1];//count
					u2 = (pDic[iDic+2] & 0xFF) + ((pDic[iDic+3] & 0xFF) << 8);
//				u2.b[1] = pDic[iDic+3];//index
//					index = u2*chnstep;
				}
			}
			else
			{//compare to pattern: [k1, k2) is key to be compared
				int minimum = min(lenK, _len);
				minimum = min(3, minimum);
				for (i=0;i<minimum;i++)
				{
					if(pattern[i] < pDic[k1+i])
					{
						noMoreCompare = 1;//keys is sorted!
						break;
					}
					else if(pattern[i] > pDic[k1+i])
						break;
				}
			}
//			preiDic = iDic;
			if(match)
			{
				String buf = m_pGbk.substring(u2+1, u2+u);//  temp!
				arrChars.add(buf);
				
			}
			
			iDic += 4;
		}
		return match;
	}
	
//////////////////////////////////////////////////////////////////
	boolean Load1KeyPyDic()
	{
		String str, _str, cur;
		int index;
		str = TextProc.xLoad_File2String(m_context.getResources(), R.raw.py_1key8); //this.getResources()
		_str = str.replaceAll("\n\r", "\n");
		_str = str.replaceAll("\r\n", "\n");
		String[] arr = _str.split("\n");
		for(int i = 0; i < m_str1KeyPyDic.length; i++ )
		{
			m_str1KeyPyDic[i] = "";
		}
		
		for(int i = 0; i < arr.length; i++ )
		{
			cur = arr[i];
			if(cur.length() == 0)
				continue;
			index = cur.charAt(0)-'a';
			if(0 > index || index >= m_str1KeyPyDic.length)
				continue;
			
			m_str1KeyPyDic[index] = arr[i+1];
			i++;
		}
		arr = null;
		return true;
	}
	
	boolean InitKey2ChsDicPY()
	{
		m_pGbk = TextProc.xLoad_File2String(m_context.getResources(), R.raw.gbkflat8);

		
		if(m_pGbk == null)
		{
			// NSLog(@"init gbkflat >>> Open Error.");
			return false;
		}


		m_pDic = TextProc.xLoad_File(m_context.getResources(), R.raw.pykeys);
		
		if(m_pDic == null)
		{
//			NSLog(@"init pydic >>> Open Error.");
			return false;
		}
		
		BuildIdx2KeysInDic();
		
		return true;
	}
	
	void initChinese() {
		
		// chinese dic init.
		CPyDictionary();
		InitFirst();
		InitDictionary();
		
	}
	
}
