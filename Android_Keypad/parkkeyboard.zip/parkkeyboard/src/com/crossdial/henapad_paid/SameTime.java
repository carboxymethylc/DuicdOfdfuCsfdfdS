﻿/*
 *  SameTime.java
 *  12MonkeyPad
 *
 *  Created by z on 2010/10.
 *  Modified by z.c. on 2010/10 - 2012/03.
 *  Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 */

package com.crossdial.henapad_paid;

import android.inputmethodservice.Keyboard.Key;
import android.content.res.Resources;

import java.util.ArrayList;

import com.crossdial.henapad_paid.LatinKeyboard.LatinKey;
import com.crossdial.henapad_paid.R;


public class SameTime 
{
	public boolean isReplaceable; //key up & inserted
	
	boolean isSametimeDown;
	boolean isRegSametimeDown;
	
	double lastKeyTime;
	Key lastKeyRegion;
	
	LatinKey region1;
	LatinKey region2;
	
	
	/**
	 * 나중에 수정해야 할곳.
	 */
	private double KEY_SAMETIME_TIME = 150;// 밀리초
	public static final int SK_EXCHANGE = 1;// zc 
	
	private ArrayList<String> m_sametimeWordList;
	private ArrayList<String> m_sametimeWordListX;
	
	public String m_word;
	public ParkKeyboard keyView = null;
	
	boolean isEnglishChar(int ch)
	{
		if( ch >= 'a' && ch <= 'z' )
			return true;
		
		if( ch >= 'A' && ch <= 'Z' )
			return true;
		
		return false;
	}
	
	public SameTime(Resources res)
	{
		initMembers(res);
	}
	
	
	void initMembers(Resources res)
	{
		if(ParkKeyboard.DEBUG)
			KEY_SAMETIME_TIME = 1000;
		isReplaceable = false;
		lastKeyTime = 0;
		lastKeyRegion = null;
		region1 = null;
		region2 = null;
		
		String sametimeList;
		sametimeList = TextProc.xLoad_File2String(res, R.raw.sametimelist); //this.getResources()
		m_sametimeWordList = new ArrayList<String>();
		m_sametimeWordListX = new ArrayList<String>();
		TextProc.getWordArray(sametimeList, m_sametimeWordList, m_sametimeWordListX);
		
	}
	
	public void setNewEnglishRegion(Key region)
	{
		long curTime = System.currentTimeMillis();
		
		isReplaceable = false;
		lastKeyRegion = region;
		lastKeyTime = curTime;
		
	}
	
	public boolean isKoreanKey_ (int ch)
	{
		
		if(ch >= 0x1100 && ch <= 0x3400)
		{
			return true;
		}
		return false;
		
	}
	
	public void RegionDown(int primaryCode, Key region)
	{
		if( region == null ) 
		{
			// [this setNewEnglishRegion:null];
			return;
		}
		
		// String key = region.key;
		int firstChar = primaryCode;
		long curTime = System.currentTimeMillis();
		
		if( firstChar == SK_EXCHANGE )
		{
			
		}
		else if( isEnglishChar(firstChar) || isKoreanKey_(firstChar) )
		{
			boolean bProcessed = false;
			if(lastKeyRegion != null)
			{
				double delta = curTime - lastKeyTime;
				if(delta <  KEY_SAMETIME_TIME && delta >= 0)
				{
					// 동시타 성립.
					region1 = (LatinKey)lastKeyRegion;
					region2 = (LatinKey)region;
					isSametimeDown = true;
					if( this.checkSametimeKey() )
					{
						// 동시타로 처리 된다.
						this.setNewEnglishRegion(null);
						isRegSametimeDown = true;
						bProcessed = true;
					}
				}
			}
			
			if(bProcessed != true)
			{
				this.setNewEnglishRegion(region);
			}
			
		}
		else
		{
			this.setNewEnglishRegion(null);
		}
	}
	
	void insertSametimeWord()
	{
		if( !region1.bDownImage || !region2.bDownImage )// zc error.
		{
			// 한 글자를 지워버린다.
			keyView.handleBackspace();
		}
		
		boolean bShift = keyView.mInputView.isShifted();
		
		if(bShift == false)
		{
			m_word = m_word.toLowerCase();
		}
		// 동시타 입력
		Logx.i("crossdial", String.format("동시타 입력 m_word = %s", m_word));
		
		keyView.onText(m_word);//CharSequence text
	}
	
	public boolean RegionUp(Key region)
	{
		if(region == null)
			return false;
		boolean bInsert = false;
		if( isSametimeDown )
		{
			if(region == region1 || region == region2)
				isReplaceable = true; 
			else
				isReplaceable = false;
			
			if( isRegSametimeDown )
			{
				this.insertSametimeWord();
				bInsert = true;
			}
			isSametimeDown = false;
			isRegSametimeDown = false;
		}
		return bInsert;
	}
	
	boolean checkSametimeKey()
	{
		m_word = null;
		
		LatinKey region;
		char []str = new char[5];
		char first, second;
		region = region1;
		first = str[0] = (char)region.codes[0];
		region = region2;
		second = str[1] = (char)region.codes[0];
		str[2] = 0;
		
		String string, stringInv;
		
		string = String.format("%c%c", first, second);//stringWithCharacters:str length:2];
		string = string.toUpperCase();
		
		str[0] = second;
		str[1] = first;
		stringInv = String.format("%c%c", second, first);
		stringInv = stringInv.toUpperCase();
		
		
		if ( TextProc.isKoreanJamo(first, second) )
		{
			m_word = string;
		}
		
		if ( TextProc.isKoreanJamo(second, first) )
		{
			m_word = stringInv;
		}
		
		if( m_word != null)
		{
			// 동시치기 발견.
			Logx.i("crossdial", String.format("\n 동시치기(초성+중성) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ m_word = %s", m_word));
			return true;
		}
		
		
		int idx;
		idx = TextProc.findCandidate(string, m_sametimeWordList);
		if( idx == -1 )
		{
			idx = TextProc.findCandidate(stringInv, m_sametimeWordList);
		}
		
		if( idx == -1 ) // 조합에 없는 동시 치기.
		{
			Logx.i("crossdial", String.format("\n 동시치기(사전없음) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ string = %s ", string));
			m_word = null;
			return false;
		}
		
		m_word = m_sametimeWordListX.get(idx);
		
		// 동시치기 발견.
		Logx.i("crossdial", String.format("\n 동시치기(사전에 있다) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ string = %s m_word = %s", string, m_word));
		return true;
		
	}
}