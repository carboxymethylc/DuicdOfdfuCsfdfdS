﻿/*
 * Copyright (C) 2008-2009 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.crossdial.henapad_paid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard.Key;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.PopupWindow;
import android.widget.TextView;


import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;

import com.crossdial.henapad_paid.LatinKeyboard.LatinKey;
import com.crossdial.henapad_paid.R;

//import com.android.internal.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A view that renders a virtual {@link Keyboard}. It handles rendering of keys and
 * detecting key presses and touch movements.
 * 
 * @attr ref android.R.styleable#KeyboardView_keyBackground
 * @attr ref android.R.styleable#KeyboardView_keyPreviewLayout
 * @attr ref android.R.styleable#KeyboardView_keyPreviewOffset
 * @attr ref android.R.styleable#KeyboardView_labelTextSize
 * @attr ref android.R.styleable#KeyboardView_keyTextSize
 * @attr ref android.R.styleable#KeyboardView_keyTextColor
 * @attr ref android.R.styleable#KeyboardView_verticalCorrection
 * @attr ref android.R.styleable#KeyboardView_popupLayout
 */
public class KeyboardViewEx extends KeyboardView {

	protected static final int KEYCODE_OPTIONS = -100;
	protected static final int FIRE_THRESHOLD = 12;
	protected static final int FIRE_THRESHOLD_Y_MAX = 50;
	protected static final int FIRE_THRESHOLD_OUT_X_MAX = 50;
	
	protected static final int FIRE_THRESHOLD_X_MAX = 50;
	protected static final int FIRE_THRESHOLD_OUT_Y_MAX = 50;

	protected static final int LEFT_SMALL = -99;
	protected static final int RIGHT_SMALL = -90;
	
	public int lastCode;
    public float lastX, lastY;
    public LatinKey lastTouchKey = null;
    
//    private static final boolean DEBUG = false;
    public static final int NOT_A_KEY = -1;
    private static final int[] KEY_DELETE = { Keyboard.KEYCODE_DELETE };
    private static final int[] LONG_PRESSABLE_STATE_SET = EMPTY_STATE_SET;//zc { R.attr.state_long_pressable };   
    
    private Keyboard mKeyboard;
    private int mCurrentKeyIndex = NOT_A_KEY;
    
    private TextView mPreviewText;
    private PopupWindow mPreviewPopup;
    private int mPreviewOffset;
    private int mPreviewHeight;
    private int[] mOffsetInWindow;

    private PopupWindow mPopupKeyboard;
    private View mMiniKeyboardContainer;
    private KeyboardView mMiniKeyboard;
    
    public boolean mMiniKeyboardOnScreen=false;
    
    private View mPopupParent;
    private int mMiniKeyboardOffsetX;
    private int mMiniKeyboardOffsetY;
    private Map<Key,View> mMiniKeyboardCache;
    private int[] mWindowOffset;
    private Key[] mKeys;

    /** Listener for {@link OnKeyboardActionListener}. */
    private OnKeyboardActionListener mKeyboardActionListener;
    
    protected static final int MSG_SHOW_PREVIEW = 1;
    protected static final int MSG_REMOVE_PREVIEW = 2;
    protected static final int MSG_REPEAT = 3;
    protected static final int MSG_LONGPRESS = 4;

    private static final int DELAY_BEFORE_PREVIEW = 0;//40;
    private static final int DELAY_AFTER_PREVIEW = 100;//60;
    
    private boolean mPreviewCentered = false;
    private boolean mShowPreview = true;
    private int mPopupPreviewX;
    private int mPopupPreviewY;

    
    private Paint mPaint;
    
    public int mCurrentKey = NOT_A_KEY;
    
    private int mPopupX;
    private int mPopupY;
    public int mRepeatKeyIndex = NOT_A_KEY;
    
    //private Drawable mKeyBackground;

    private static final int REPEAT_INTERVAL = 50; // ~20 keys per second
    private static final int REPEAT_START_DELAY = 400;
    private static final int LONGPRESS_TIMEOUT = 1000;
    // Deemed to be too short : ViewConfiguration.getLongPressTimeout();

    // For multi-tap
    private int mLastSentIndex;
    private int mTapCount;
    private long mLastTapTime;
    private boolean mInMultiTap;
    private static final int MULTITAP_INTERVAL = 800; // milliseconds
    
    protected Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SHOW_PREVIEW:
                    showKey(msg.arg1);
                    break;
                case MSG_REMOVE_PREVIEW:
                	if(mPreviewText != null)
                		mPreviewText.setVisibility(INVISIBLE);
                    break;
                case MSG_REPEAT:
                    if (repeatKey()) {
                        Message repeat = Message.obtain(this, MSG_REPEAT);
                        sendMessageDelayed(repeat, REPEAT_INTERVAL);                        
                    }
                    break;
                case MSG_LONGPRESS:
                    openPopupIfRequired((MotionEvent) msg.obj);
                    break;
            }
        }
    };
    
    int mPaddingLeft = 2;
    int mPaddingTop = 2;
    int mPaddingRight = 2;
    int mPaddingBottom = 2;
    
    public KeyboardViewEx(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public KeyboardViewEx(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    private void init(Context context)
    {
    	mPreviewHeight = 80;
        
        mPopupKeyboard = new PopupWindow(context);
        mPopupKeyboard.setBackgroundDrawable(null);
        
        mPopupParent = this;
        //mPredicting = true;
        
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setTextAlign(Align.CENTER);

        mMiniKeyboardCache = new HashMap<Key,View>();
        resetMultiTap();
        
    	// 팝업 뷰를 창조한다.
        mPreviewPopup = new PopupWindow(context);

        initPopupView();
    }
    
    void initPopupView()
    {
       	// 팝업 뷰를 창조한다.
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);

        
        int previewLayout = R.layout.monkeyboard_key_preview;
        if (previewLayout != 0) {
            mPreviewText = (TextView) inflater.inflate(previewLayout, null);
            mPreviewPopup.setContentView(mPreviewText);
            mPreviewPopup.setBackgroundDrawable(null);
        } else {
            mShowPreview = false;
        }
        
        mPreviewPopup.setTouchable(false);	
    }
    
    public void onDraw(Canvas canvas) {
    	super.onDraw(canvas);
	    // Overlay a dark rectangle to dim the keyboard
	    if (mMiniKeyboardOnScreen) {
	    	final Paint paint = mPaint;
	    	//paint.setAlpha(255);
            paint.setAlpha(100);
            paint.setColor(0x55555555);
	    	//paint.setColor((int) (mBackgroundDimAmount * 0xFF) << 24);
	        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
	    }
    }
    @Override
    public void setOnKeyboardActionListener(OnKeyboardActionListener listener) {
		super.setOnKeyboardActionListener(listener);
        mKeyboardActionListener = listener;
    }

    /**
     * Returns the {@link OnKeyboardActionListener} object.
     * @return the listener attached to this keyboard
     */
    @Override
	protected OnKeyboardActionListener getOnKeyboardActionListener() {
        return mKeyboardActionListener;
    }

    /**
     * Attaches a keyboard to this view. The keyboard can be switched at any time and the
     * view will re-layout itself to accommodate the keyboard.
     * @see Keyboard
     * @see #getKeyboard()
     * @param keyboard the keyboard to display in this view
     */
    @Override
    public void setKeyboard(Keyboard keyboard) {
    	super.setKeyboard(keyboard);
    	
        if (mKeyboard != null) {
            
        }
        mKeyboard = keyboard;
        List<Key> keys = mKeyboard.getKeys();
        mKeys = keys.toArray(new Key[keys.size()]);
        requestLayout();
        // Release buffer, just in case the new keyboard has a different size. 
        // It will be reallocated on the next draw.
        mMiniKeyboardCache.clear(); // Not really necessary to do every time, but will free up views
    }

    /**
     * Returns the current keyboard being displayed by this view.
     * @return the currently attached keyboard
     * @see #setKeyboard(Keyboard)
     */
    public Keyboard getKeyboard() {
        return mKeyboard;
    }
    
    /**
     * Returns the enabled state of the key feedback popup.
     * @return whether or not the key feedback popup is enabled
     * @see #setPreviewEnabled(boolean)
     */
	@Override
    public boolean isPreviewEnabled() {
        return mShowPreview;
    }

    @Override
    public void setPopupParent(View v) {
		super.setPopupParent(v);
        mPopupParent = v;
    }
    
	@Override
    public void setPopupOffset(int x, int y) {
		super.setPopupOffset(x, y);
        mMiniKeyboardOffsetX = x;
        mMiniKeyboardOffsetY = y;
        if (mPreviewPopup.isShowing()) {
            mPreviewPopup.dismiss();
        }
    }

    /** 
     * Popup keyboard close button clicked.
     * @hide 
     */
    public void onClick(View v) {
        dismissPopupKeyboard();
    }
    
    @Override public void invalidateKey(int i)
    {
    	
    }
    
    protected void showPreview(int keyIndex) {
        int oldKeyIndex = mCurrentKeyIndex;
        final PopupWindow previewPopup = mPreviewPopup;
        
        mCurrentKeyIndex = keyIndex;
        // Release the old key and press the new key
        final Key[] keys = mKeys;
        if (oldKeyIndex != mCurrentKeyIndex) {
            if (oldKeyIndex != NOT_A_KEY && keys.length > oldKeyIndex) {
                keys[oldKeyIndex].onReleased(mCurrentKeyIndex == NOT_A_KEY);
//                invalidateKey(oldKeyIndex);
            }
            if (mCurrentKeyIndex != NOT_A_KEY && keys.length > mCurrentKeyIndex) {
                keys[mCurrentKeyIndex].onPressed();
                invalidateKey(mCurrentKeyIndex);
            }
        }
        // If key changed and preview is on ...
        if (oldKeyIndex != mCurrentKeyIndex && mShowPreview) {
            mHandler.removeMessages(MSG_SHOW_PREVIEW);
            if (previewPopup.isShowing()) {
                if (keyIndex == NOT_A_KEY) {
                    mHandler.sendMessageDelayed(mHandler
                            .obtainMessage(MSG_REMOVE_PREVIEW), 
                            DELAY_AFTER_PREVIEW);
                }
            }
            if (keyIndex != NOT_A_KEY) {
                if (previewPopup.isShowing() && mPreviewText.getVisibility() == VISIBLE) {
                    // Show right away, if it's already visible and finger is moving around
                    showKey(keyIndex);
                } else {
                    mHandler.sendMessageDelayed(
                            mHandler.obtainMessage(MSG_SHOW_PREVIEW, keyIndex, 0), 
                            DELAY_BEFORE_PREVIEW);
                }
            }
        }
    }
    
    private void showKey(final int keyIndex) {
        final PopupWindow previewPopup = mPreviewPopup;
        final Key[] keys = mKeys;
        
        Key key = keys[keyIndex];
        Drawable drawable = key.iconPreview != null ? key.iconPreview : key.icon;
        drawable = key.iconPreview;//
        int w_width, w_height;
        if (drawable != null) {
            mPreviewText.setCompoundDrawables(null, drawable, null, null);
            w_width = drawable.getBounds().width();
            w_height = drawable.getBounds().height();
            mPreviewText.setText(null);
        } 
        else
        {
        	return;
        }
        	
        mHandler.removeMessages(MSG_REMOVE_PREVIEW);
        mPreviewText.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), 
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        int popupWidth = Math.max(mPreviewText.getMeasuredWidth(), key.width 
                + mPreviewText.getPaddingLeft() + mPreviewText.getPaddingRight());
        popupWidth = Math.max(popupWidth, w_width);
        popupWidth = w_width;
        
        int popupHeight = mPreviewHeight;
        popupHeight = w_height;
        
        LayoutParams lp = mPreviewText.getLayoutParams();
        if (lp != null) {
            lp.width = popupWidth;
            lp.height = popupHeight;
        }
        if (!mPreviewCentered) {
            mPopupPreviewX = key.x - mPreviewText.getPaddingLeft() + mPaddingLeft;
            mPopupPreviewY = key.y - popupHeight + mPreviewOffset;
        } else {
            // TODO: Fix this if centering is brought back
            mPopupPreviewX = 160 - mPreviewText.getMeasuredWidth() / 2;
            mPopupPreviewY = - mPreviewText.getMeasuredHeight();
        }
        if (mOffsetInWindow == null) {
            mOffsetInWindow = new int[2];
            getLocationInWindow(mOffsetInWindow);
            mOffsetInWindow[0] += mMiniKeyboardOffsetX; // Offset may be zero
            mOffsetInWindow[1] += mMiniKeyboardOffsetY; // Offset may be zero
        }
        // Set the preview background state
        
        if(mPreviewText.getBackground() != null)
        {
	        mPreviewText.getBackground().setState(
	                key.popupResId != 0 ? LONG_PRESSABLE_STATE_SET : EMPTY_STATE_SET);
        }
        
        if (previewPopup.isShowing()) {
            previewPopup.update(mPopupPreviewX + mOffsetInWindow[0],
                    mPopupPreviewY + mOffsetInWindow[1], 
                    popupWidth, popupHeight);
        } else {
            previewPopup.setWidth(popupWidth);
            previewPopup.setHeight(popupHeight);
            previewPopup.showAtLocation(mPopupParent, Gravity.NO_GRAVITY, 
                    mPopupPreviewX + mOffsetInWindow[0], 
                    mPopupPreviewY + mOffsetInWindow[1]);
        }
        mPreviewText.setVisibility(VISIBLE);
    }
    
    private boolean openPopupIfRequired(MotionEvent me) {
        // Check if we have a popup layout specified first.
 
    	if(lastTouchKey == null) return false;
        Key popupKey = lastTouchKey;        
        boolean result = onLongPress(popupKey);
        if (result) {
            showPreview(NOT_A_KEY);
        }
        return result;
    }
    
	/*
     * Called when a key is long pressed. By default this will open any popup keyboard associated
     * with this key through the attributes popupLayout and popupCharacters.
     * @param popupKey the key that was long pressed
     * @return true if the long press is handled, false otherwise. Subclasses should call the
     * method on the base class if the subclass doesn't wish to handle the call.
     */
    protected boolean onLongPress(Key popupKey) {
    	
    	if(popupKey == null) return false;
    	
        int popupKeyboardId = popupKey.popupResId;

        if (popupKeyboardId != 0) {
            mMiniKeyboardContainer = mMiniKeyboardCache.get(popupKey);
            if (mMiniKeyboardContainer == null) {
            	// 팝업 뷰를 창조한다.
                LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);

                int resId = R.layout.keyboard_popup_keyboard;
                mMiniKeyboardContainer = inflater.inflate(resId, null);
                mMiniKeyboard = (KeyboardView) mMiniKeyboardContainer.findViewById(
                        android.R.id.keyboardView);
                View closeButton = mMiniKeyboardContainer.findViewById(
                        android.R.id.closeButton);
                if (closeButton != null) closeButton.setOnClickListener(this);
                
                mMiniKeyboard.setOnKeyboardActionListener(new OnKeyboardActionListener() {
                    public void onKey(int primaryCode, int[] keyCodes) {
                        mKeyboardActionListener.onKey(primaryCode, keyCodes);
                        dismissPopupKeyboard();
                    }
                    
                    public void onText(CharSequence text) {
                        mKeyboardActionListener.onText(text);
                        dismissPopupKeyboard();
                    }
                    
                    public void swipeLeft() { }
                    public void swipeRight() { }
                    public void swipeUp() { }
                    public void swipeDown() { }
                    public void onPress(int primaryCode) {
                        mKeyboardActionListener.onPress(primaryCode);
                    }
                    public void onRelease(int primaryCode) {
                        mKeyboardActionListener.onRelease(primaryCode);
                    }
                });

                // 팝업 키보드를 창조한다.
                Keyboard keyboard;
                if (popupKey.popupCharacters != null) {
                    keyboard = new Keyboard(getContext(), popupKeyboardId, 
                            popupKey.popupCharacters, -1, 100);
                } else {
                    keyboard = new Keyboard(getContext(), popupKeyboardId);
                }
                mMiniKeyboard.setKeyboard(keyboard);
                mMiniKeyboard.setPopupParent(this);
                mMiniKeyboardContainer.measure(
                        MeasureSpec.makeMeasureSpec(getWidth(), MeasureSpec.AT_MOST), 
                        MeasureSpec.makeMeasureSpec(getHeight(), MeasureSpec.AT_MOST));
                
                // 캐시에 등록한다.
                mMiniKeyboardCache.put(popupKey, mMiniKeyboardContainer);
                
            } else {
                mMiniKeyboard = (KeyboardView) mMiniKeyboardContainer.findViewById(
                        android.R.id.keyboardView);
            }
            if (mWindowOffset == null) {
                mWindowOffset = new int[2];
                getLocationInWindow(mWindowOffset);
            }
            
            // 팝업의 위치등 최종 정보들을 결정한다.
            mPopupX = popupKey.x + mPaddingLeft;
            mPopupY = popupKey.y + mPaddingTop;
            mPopupX = mPopupX + popupKey.width - mMiniKeyboardContainer.getMeasuredWidth();
            mPopupY = mPopupY - mMiniKeyboardContainer.getMeasuredHeight();
            final int x = popupKey.x + popupKey.width/2 - mMiniKeyboardContainer.getMeasuredWidth()/2;
            final int y = mPopupY + mMiniKeyboardContainer.getPaddingBottom() + mWindowOffset[1];
            mMiniKeyboard.setPopupOffset(x < 0 ? 0 : x, y);
            
			mMiniKeyboard.setPreviewEnabled(true/*false*/);
            mMiniKeyboard.setShifted(isShifted());
            mPopupKeyboard.setContentView(mMiniKeyboardContainer);
            mPopupKeyboard.setWidth(mMiniKeyboardContainer.getMeasuredWidth());
            mPopupKeyboard.setHeight(mMiniKeyboardContainer.getMeasuredHeight());
            mPopupKeyboard.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
            mMiniKeyboardOnScreen = true;
            //mMiniKeyboard.onTouchEvent(getTranslatedEvent(me));
            invalidateAllKeys();
            return true;
        }
        return false;
    }

    /**
     * 터치된 좌표에 기초하여 키 사건을 발생시킨다.
     */
    private void detectAndSendKey(int x, int y, long eventTime) {
        int index = mCurrentKey;
        if (index != NOT_A_KEY && index < mKeys.length) {
            final Key key = mKeys[index];
            if (key.text != null) {
                mKeyboardActionListener.onText(key.text);
                mKeyboardActionListener.onRelease(NOT_A_KEY);
            } else {
                int code = key.codes[0];

                int[] codes;
                codes = key.codes;
                // Multi-tap
                if (mInMultiTap) {
                    if (mTapCount != -1) {
                        mKeyboardActionListener.onKey(Keyboard.KEYCODE_DELETE, KEY_DELETE);
                    } else {
                        mTapCount = 0;
                    }
                    code = key.codes[mTapCount];
                }
                mKeyboardActionListener.onKey(code, codes);
                mKeyboardActionListener.onRelease(code);
            }
            mLastSentIndex = index;
            mLastTapTime = eventTime;
        }
    }
    
    // 반복키에 대한  처리를 한다.
    private boolean repeatKey() {
        Key key = mKeys[mRepeatKeyIndex];
        detectAndSendKey(key.x, key.y, mLastTapTime);
        return true;
    }

    // 더블터치에 대한 처리를 한다.
    private void resetMultiTap() {
        mLastSentIndex = NOT_A_KEY;
        mTapCount = 0;
        mLastTapTime = -1;
        mInMultiTap = false;
    }
    
    // 더블터치를 체크한다.
    private void checkMultiTap(long eventTime, int keyIndex) {
        if (keyIndex == NOT_A_KEY) return;
        Key key = mKeys[keyIndex];
        if (key.codes.length > 1) {
            mInMultiTap = true;
            if (eventTime < mLastTapTime + MULTITAP_INTERVAL
                    && keyIndex == mLastSentIndex) {
                mTapCount = (mTapCount + 1) % key.codes.length;
                return;
            } else {
                mTapCount = -1;
                return;
            }
        }
        if (eventTime > mLastTapTime + MULTITAP_INTERVAL || keyIndex != mLastSentIndex) {
            resetMultiTap();
        }
    }

    // 팝업을 감춘다.
    public void dismissPopupKeyboard() {
        if (mPopupKeyboard.isShowing()) {
            mPopupKeyboard.dismiss();
            mMiniKeyboardOnScreen = false;
            lastTouchKey = null;
            invalidateAllKeys();
        }
    }
    
    // 
    protected int checkKeyIndex(float x, float y, boolean bSetting)
    {
    	Key key;
    	List<Key> mKeys = this.getKeyboard().getKeys();
        for (int i = 0; i < mKeys.size(); i++) {
        	key = mKeys.get(i);
        	// 2010-10-13 Add by KUH
        	if (key.isInside((int)x, (int)y)) {
        		if(bSetting)
        		{
        			lastTouchKey = (LatinKey) key;
	        		lastCode = lastTouchKey.codes[0];
	        		lastX = x;
	        		lastY = y;
        		}
        		return i;
        	}
        }
        
		if(bSetting)
		{
			lastTouchKey = (LatinKey) null;
    		lastCode = NOT_A_KEY;
    		lastX = x;
    		lastY = y;
		}
        return NOT_A_KEY;
    }
    
    public boolean onTouchEvent(MotionEvent event) {
    	float x = event.getX();
    	float y = event.getY();
    	int curKeyIndex = checkKeyIndex(x, y, false);
    	long eventTime = event.getEventTime();
    	
    	switch (event.getAction()) {
    	case MotionEvent.ACTION_DOWN:
    		if (lastTouchKey != null) {
                checkMultiTap(eventTime, curKeyIndex);
                
                mKeyboardActionListener.onPress(curKeyIndex != NOT_A_KEY ? 
                        mKeys[curKeyIndex].codes[0] : 0);
                if (mCurrentKey >= 0 && mKeys[mCurrentKey].repeatable) {
                    mRepeatKeyIndex = mCurrentKey;
                    repeatKey();
                    Message msg = mHandler.obtainMessage(MSG_REPEAT);
                    mHandler.sendMessageDelayed(msg, REPEAT_START_DELAY);
                }
                
    			Message msg = mHandler.obtainMessage(MSG_LONGPRESS, event);
    			mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
    			curKeyIndex = checkKeyIndex(x, y, false);
    			
    			showPreview(curKeyIndex);
    		
    		}
    		break;
    		
    	case MotionEvent.ACTION_MOVE:
    		boolean continueLongPress = false;
    		if (curKeyIndex != NOT_A_KEY) {
    			if (mCurrentKey == NOT_A_KEY) {
    				// mCurrentKey = keyIndex;
    			} else {
    				if (curKeyIndex == mCurrentKey) {
    					continueLongPress = true;
    				} else {
    					resetMultiTap();
    					// mCurrentKey = keyIndex;
    				}
    			}
    			
    			if (curKeyIndex != mRepeatKeyIndex) {
    				mHandler.removeMessages(MSG_REPEAT);
    				mRepeatKeyIndex = NOT_A_KEY;
    			}
    		}
    		if (!continueLongPress) {
    			// Cancel old longpress
    			mHandler.removeMessages(MSG_LONGPRESS);
    			// Start new longpress if key has changed
    			if (curKeyIndex != NOT_A_KEY) {
    				// Message msg = mHandler.obtainMessage(MSG_LONGPRESS, event);
    				// mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
    			}
    		}
    		break;
    		
    	case MotionEvent.ACTION_UP:
    		mHandler.removeMessages(MSG_SHOW_PREVIEW);
    		mHandler.removeMessages(MSG_REPEAT);
    		mHandler.removeMessages(MSG_LONGPRESS);
    		
            if (mRepeatKeyIndex == NOT_A_KEY && !mMiniKeyboardOnScreen) {
                detectAndSendKey((int)lastX, (int)lastY, eventTime);
            }
            mRepeatKeyIndex = NOT_A_KEY;
            
            showPreview(NOT_A_KEY);
            break;
    	}
    	return true;
    }
    
    public static boolean checkDragChar()
    {
    	boolean ret = false;
    	return ret;
    }
    
}