﻿/*
 * Created by z.c. on 2010/10.
 * Modified by z.c. on 2010/10 - 2012/03.
 * Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 */

package com.crossdial.henapad_paid;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.view.inputmethod.EditorInfo;

public class LatinKeyboard extends Keyboard {

	private static final float SMALL_LETTER_SQUARE_PERCENT_SIZE = .5f;
	public static final String g_strPackage = "com.crossdial.henapad_paid";
	private Key mEnterKey;
	private Key mShiftKey;
	private Key mBlockKey;
	private Drawable mShiftGreenIcon;
	private Drawable mShiftCapsIcon;
	private Drawable mOrgShiftIcon;
	private Drawable mBlockIcon;
	private Drawable mBlockSelIcon;

	private Drawable mReturnIcon;
	private Drawable mSearchIcon;
	private Drawable mSendIcon;
	private Drawable mNextIcon;
	private Drawable mGoIcon;

	private boolean mCapsState = false;
	private boolean mBlockState = false;

	public LatinKeyboard(Context context, int xmlLayoutResId) {
		super(context, xmlLayoutResId);

		resizeKeys();

	}

	public LatinKeyboard(Context context, int layoutTemplateResId, CharSequence characters, int columns, int horizontalPadding) {
		super(context, layoutTemplateResId, characters, columns, horizontalPadding);
	}

	public static void resizeKeyRect(Key key) {
		LatinKey latinkey = null;
		latinkey = (LatinKey) key;
		try {

			/*
			 * if(key.icon != null && latinkey.parentKey == null) { Rect rt =
			 * key.icon.getBounds(); float midX, midY;
			 * 
			 * midX = key.x + (float)key.width/2; midY = key.y + (float)key.height/2;
			 * key.width = rt.width()-4; key.height = rt.height(); key.x = (int)(midX -
			 * (float)key.width/2); key.y = (int)(midY - (float)key.height/2); }
			 */

			if (key.icon != null && latinkey.parentKey == null) {
				// 이미지 리사이즈.
				key.icon.setBounds(0, 0, key.width, key.height);
			}

			if (latinkey.parentKey != null) {
				key = latinkey.parentKey;
				latinkey.setXSize(key.x, key.width);
				latinkey.height = key.height;
				latinkey.y = key.y;
			}

		} catch (Exception e) {

		}
		return;
	}

	public void resizeKeys() {
		List<Key> keys = getKeys();
		Key key;
		for (int i = keys.size() - 1; i >= 0; i--) {
			key = keys.get(i);
			resizeKeyRect(key);
		}
	}

	@Override
	protected Key createKeyFromXml(Resources res, Row parent, int x, int y, XmlResourceParser parser) {
		LatinKey key = new LatinKey(res, parent, x, y, parser);

		boolean specialKey = false;
		String name = null;
		String val = null;

		if (key.codes[0] == 10) {
			specialKey = true;
			mEnterKey = key;
			mReturnIcon = mSearchIcon = mGoIcon = mSendIcon = mNextIcon = key.icon;
		}
		if (key.codes[0] == -14) {
			specialKey = true;
			mBlockKey = key;
			mBlockSelIcon = mBlockIcon = key.icon;
		}

		if (key.codes[0] == -1) 
		{
			specialKey = true;
			mShiftKey = key;
			mShiftCapsIcon = mShiftGreenIcon = mOrgShiftIcon = key.icon;
		}

		int n = parser.getAttributeCount();
		int i;
		if (specialKey) {
			for (i = 0; i < n; i++) {
				name = parser.getAttributeName(i);
				val = parser.getAttributeValue(i);

				if (name.equalsIgnoreCase("returnImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mReturnIcon = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("searchImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mSearchIcon = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("goImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mGoIcon = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("sendImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mSendIcon = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("nextImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mNextIcon = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("shiftCapsImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mShiftCapsIcon = res.getDrawable(id);
					mShiftCapsIcon.setBounds(0, 0, key.width, key.height);
				}
				if (name.equalsIgnoreCase("shiftGreenImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mShiftGreenIcon = res.getDrawable(id);
					mShiftGreenIcon.setBounds(0, 0, key.width, key.height);
				}
				if (name.equalsIgnoreCase("blockSelImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					mBlockSelIcon = res.getDrawable(id);
					mBlockSelIcon.setBounds(0, 0, key.width, key.height);
				}
			}
		}

		if (key.subKeys != null) {
			getKeys().addAll(key.subKeys);
		}
		return key;
	}

	@Override
	public boolean setShifted(boolean shiftState) {
		if (mShiftKey != null) {
			if (shiftState == true) {
				mShiftKey.icon = mShiftGreenIcon;
			} else {
				mShiftKey.icon = mOrgShiftIcon;
			}
		}
		return super.setShifted(shiftState);
	}

	public boolean setCapsLock(boolean capsState) {
		mCapsState = capsState;
		boolean shiftState = false;
		if (capsState) {
			mShiftKey.icon = mShiftCapsIcon;
			shiftState = true;
		} else {
			mShiftKey.icon = mOrgShiftIcon;
		}
		return super.setShifted(shiftState);
	}

	public boolean _setShifted(boolean shiftState) {
		if (mShiftKey != null) {
			if (mCapsState) {
				mShiftKey.icon = mShiftCapsIcon;
				shiftState = true;
			} else if (shiftState == true) {
				mShiftKey.icon = mShiftGreenIcon;
			} else {
				mShiftKey.icon = mOrgShiftIcon;
			}
		}
		return super.setShifted(shiftState);
	}

	public void setBlock(boolean blockState) {
		mBlockState = blockState;
		if (mBlockKey != null) {
			if (blockState == true) {
				mBlockKey.icon = mBlockSelIcon;
			} else {
				mBlockKey.icon = mBlockIcon;
			}
		}
		return;
	}

	public boolean getBlock() {
		return mBlockState;
	}

	/**
	 * This looks at the ime options given by the current editor, to set the appropriate
	 * label on the keyboard's enter key (if it has one).
	 */
	void setImeOptions(Resources res, int options) {
		if (mEnterKey == null) {
			return;
		}

		if (true)
			return;

		switch (options & (EditorInfo.IME_MASK_ACTION | EditorInfo.IME_FLAG_NO_ENTER_ACTION)) {
		case EditorInfo.IME_ACTION_GO:
			mEnterKey.icon = mGoIcon;
			mEnterKey.label = null;
			break;
		case EditorInfo.IME_ACTION_NEXT:
			mEnterKey.icon = mNextIcon;
			mEnterKey.label = null;
			break;
		case EditorInfo.IME_ACTION_SEARCH:
			mEnterKey.icon = mSearchIcon;
			mEnterKey.label = null;
			break;
		case EditorInfo.IME_ACTION_SEND:
			mEnterKey.icon = mSendIcon;
			mEnterKey.label = null;
			break;
		default:
			mEnterKey.icon = mReturnIcon;
			mEnterKey.label = null;
			break;
		}
	}

	static class LatinKey extends Keyboard.Key {

		public static int displayWidth = 480;
		public static final int orgWidth = 480;

		public static final int DIRECT_EXCLUDE_TOP_LEFT = 3;
		public static final int DIRECT_EXCLUDE_TOP_RIGHT = 4;
		public static final int DIRECT_EXCLUDE_BOTTOM_LEFT = 5;
		public static final int DIRECT_EXCLUDE_BOTTOM_RIGHT = 6;

		public static final int DIRECT_LEFT = -2;
		public static final int DIRECT_MID_LEFT = -1;
		public static final int DIRECT_MID_RIGHT = 1;
		public static final int DIRECT_RIGHT = 2;
		public static final double DIV_RATE = 0.37;

		int smallLeftChar = -1;
		int smallRightChar = -1;
		int midLeftChar = -1; // 가운데 왼쪽
		int midRightChar = -1; // 가운데 오른쪽
		int leftChar = -1; // 등분하기.
		int rightChar = -1; // 등분하기.
		int shiftChar = -1;

		int excludeBottomRightChar = -1;
		int excludeBottomLeftChar = -1;
		int excludeTopRightChar = -1;
		int excludeTopLeftChar = -1;

		int mainChar = -1;
		int dragDownChar = -1;
		int dragUpChar = -1;
		int dragLeftChar = -1;
		int dragRightChar = -1;
		public Drawable downImage = null;
		public Drawable smallPreviewImage = null;
		public Drawable leftPreviewImage = null;
		public Drawable rightPreviewImage = null;
		public Drawable dragRightPreviewImage = null;
		public Drawable dragLeftPreviewImage = null;
		public Drawable dragUpPreviewImage = null;
		public Drawable dragDownPreviewImage = null;

		boolean bDownImage = false;
		int subMode = 0;
		// LatinKey subKey = null;
		LatinKey parentKey = null;
		ArrayList<LatinKey> subKeys = null;

		public void setPreview() {
			if (this.parentKey == null)
				return;
			switch (this.subMode) {
			case DIRECT_LEFT:
				this.iconPreview = this.parentKey.smallPreviewImage;
				break;

			case DIRECT_MID_LEFT:
				this.iconPreview = this.parentKey.leftPreviewImage;
				break;

			case DIRECT_MID_RIGHT:
				this.iconPreview = this.parentKey.rightPreviewImage;
				break;

			case DIRECT_RIGHT:
				this.iconPreview = this.parentKey.smallPreviewImage;
				break;

			default:
				break;
			}

		}

		public void setXSize(int x, int width) {
			switch (this.subMode) {
			case DIRECT_LEFT:
				this.x = x;
				this.width = (int) (width * DIV_RATE);
				break;

			case DIRECT_MID_LEFT:
				this.x = x;
				this.width = (int) (width / 2);
				break;

			case DIRECT_MID_RIGHT:
				this.x = x + (int) (width / 2);
				this.width = (int) (width / 2);
				break;

			case DIRECT_RIGHT:
				this.x = x + (int) (width * (1 - DIV_RATE));
				this.width = (int) (width * DIV_RATE);
				break;

			default:
				this.x = x;
				this.width = width;
				break;
			}
		}

		private void makeSubKey(int subChar, int mode, Keyboard.Row parent) {
			if (subKeys == null) {
				subKeys = new ArrayList<LatinKey>(0);
			}

			LatinKey subKey = new LatinKey(parent);
			subKey.codes = new int[1];
			subKey.codes[0] = subChar;
			subKey.mainChar = subChar;
			subKey.bDownImage = bDownImage;
			subKey.downImage = downImage;

			subKey.icon = null;// icon;
			subKey.gap = gap;
			subKey.popupCharacters = null;
			subKey.repeatable = repeatable;
			subKey.sticky = false;
			subKey.text = null;

			subKey.parentKey = this;
			subKey.y = y;
			subKey.height = height;

			subKey.subMode = mode;
			subKey.setXSize(x, width);
			subKey.setPreview();

			// 보정한다.
			subKey.y += 1;
			subKey.height -= 2;
			subKey.x += 1;
			subKey.width -= 1;

			subKeys.add(subKey);

		}

		public LatinKey(Keyboard.Row parent) {
			super(parent);
		}

		public LatinKey(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
			super(res, parent, x, y, parser);

			String name = null;
			String val = null;

			// XmlPullParser p;p.
			int n = parser.getAttributeCount();
			int i;
			Drawable drawable = null;
			for (i = 0; i < n; i++) {
				name = parser.getAttributeName(i);
				val = parser.getAttributeValue(i);

				if (name.equalsIgnoreCase("smallPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = smallPreviewImage = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("dragLeftPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = dragLeftPreviewImage = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("dragRightPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = dragRightPreviewImage = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("dragUpPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = dragUpPreviewImage = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("dragDownPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = dragDownPreviewImage = res.getDrawable(id);
				}

				if (name.equalsIgnoreCase("downImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = downImage = res.getDrawable(id);
				}

				if (name.equalsIgnoreCase("leftPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = leftPreviewImage = res.getDrawable(id);
				}
				if (name.equalsIgnoreCase("rightPreviewImage")) {
					int id = res.getIdentifier(val, "draw", g_strPackage);
					drawable = rightPreviewImage = res.getDrawable(id);
				}

				if (name.equalsIgnoreCase("mainChar")) {
					mainChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("shiftChar")) {
					shiftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("leftChar")) {
					leftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("rightChar")) {
					rightChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("midLeftChar")) {
					midLeftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("midRightChar")) {
					midRightChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("smallLeftChar")) {
					smallLeftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("smallRightChar")) {
					smallRightChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("dragLeftChar")) {
					dragLeftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("dragRightChar")) {
					dragRightChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("dragUpChar")) {
					dragUpChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("dragDownChar")) {
					dragDownChar = val.charAt(0);
				}
				if (name.equals("excludeBottomRightChar")) {
					excludeBottomRightChar = val.charAt(0);
				}
				if (name.equals("excludeBottomLeftChar")) {
					excludeBottomLeftChar = val.charAt(0);
				}
				if (name.equals("excludeTopRightChar")) {
					excludeTopRightChar = val.charAt(0);
				}
				if (name.equals("excludeTopLeftChar")) {
					excludeTopLeftChar = val.charAt(0);
				}
				if (name.equalsIgnoreCase("x")) {
					this.x = Integer.parseInt(val);
				}
				if (name.equalsIgnoreCase("y")) {
					this.y = Integer.parseInt(val);
				}
				if (drawable != null) {
					drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
					drawable = null;
				}
			}

			if (smallLeftChar >= 0)
				makeSubKey(smallLeftChar, DIRECT_LEFT, parent);
			if (smallRightChar >= 0)
				makeSubKey(smallRightChar, DIRECT_RIGHT, parent);
			if (leftChar >= 0)
				makeSubKey(leftChar, DIRECT_MID_LEFT, parent);
			if (rightChar >= 0)
				makeSubKey(rightChar, DIRECT_MID_RIGHT, parent);
			if (excludeBottomRightChar >= 0)
				makeSubKey(excludeBottomRightChar, DIRECT_EXCLUDE_BOTTOM_RIGHT, parent);
			if (excludeBottomLeftChar >= 0)
				makeSubKey(excludeBottomLeftChar, DIRECT_EXCLUDE_BOTTOM_LEFT, parent);
			if (excludeTopRightChar >= 0)
				makeSubKey(excludeTopRightChar, DIRECT_EXCLUDE_TOP_RIGHT, parent);
			if (excludeTopLeftChar >= 0)
				makeSubKey(excludeTopLeftChar, DIRECT_EXCLUDE_TOP_LEFT, parent);
		}

		/**
		 * Overriding this method so that we can reduce the target area for the key that
		 * closes the keyboard.
		 */
		@Override
		public boolean isInside(int x, int y) {
			boolean superBool = super.isInside(x, codes[0] == KEYCODE_CANCEL ? y - 10 : y);

			if (this.parentKey != null) {
				// I am a subKey :)
				Key key = this.parentKey;
				int halfSize = (int) (key.height * SMALL_LETTER_SQUARE_PERCENT_SIZE / 2);
				Rect topRightBounds = squareFromPoint(key.x + key.width - halfSize, key.y + halfSize, halfSize);
				Rect topLeftBounds = squareFromPoint(key.x + halfSize, key.y + halfSize, halfSize);
				Rect bottomRightBounds = squareFromPoint(key.x + key.width - halfSize, key.y + key.height - halfSize, halfSize);
				Rect bottomLeftBounds = squareFromPoint(key.x + halfSize, key.y + key.height - halfSize, halfSize);

				Rect bounds = null;

				if (this.subMode == DIRECT_EXCLUDE_BOTTOM_RIGHT) {
					bounds = bottomRightBounds;
				} else if (this.subMode == DIRECT_EXCLUDE_BOTTOM_LEFT) {
					bounds = bottomLeftBounds;
				} else if (this.subMode == DIRECT_EXCLUDE_TOP_LEFT) {
					bounds = topLeftBounds;
				} else if (this.subMode == DIRECT_EXCLUDE_TOP_RIGHT) {
					bounds = topRightBounds;
				}

				if (bounds != null) {
					return bounds.contains(x, y);
				}
			} else {
				// I am a normal key
				if (superBool) {
					Key key = this;
					int halfSize = (int) (key.height * SMALL_LETTER_SQUARE_PERCENT_SIZE / 2);
					Rect topRightBounds = squareFromPoint(key.x + key.width - halfSize, key.y + halfSize, halfSize);
					Rect topLeftBounds = squareFromPoint(key.x + halfSize, key.y + halfSize, halfSize);
					Rect bottomRightBounds = squareFromPoint(key.x + key.width - halfSize, key.y + key.height - halfSize, halfSize);
					Rect bottomLeftBounds = squareFromPoint(key.x + halfSize, key.y + key.height - halfSize, halfSize);

					if (excludeBottomRightChar >= 0 && bottomRightBounds.contains(x, y)) {
						return false;
					}

					if (excludeBottomLeftChar >= 0 && bottomLeftBounds.contains(x, y)) {
						return false;
					}

					if (excludeTopLeftChar >= 0 && topLeftBounds.contains(x, y)) {
						return false;
					}

					if (excludeTopRightChar >= 0 && topRightBounds.contains(x, y)) {
						return false;
					}
				}
			}

			return superBool;
		}

		static Rect squareFromPoint(int centerX, int centerY, int halfSize) {
			return new Rect(centerX - halfSize, centerY - halfSize, centerX + halfSize, centerY + halfSize);
		}

		/**
		 * 
		 * @param value
		 *            "123,123"
		 * @return {123,123}
		 */
		int[] parseCSV(String value) {
			int count = 0;
			int lastIndex = 0;
			if (value.length() > 0) {
				count++;
				while ((lastIndex = value.indexOf(",", lastIndex + 1)) > 0) {
					count++;
				}
			}
			int[] values = new int[count];
			count = 0;
			StringTokenizer st = new StringTokenizer(value, ",");
			while (st.hasMoreTokens()) {
				try {
					values[count++] = Integer.parseInt(st.nextToken());
				} catch (NumberFormatException nfe) {
					Logx.e("TAG", "Error parsing keycodes " + value);
				}
			}
			return values;
		}
	}

}
