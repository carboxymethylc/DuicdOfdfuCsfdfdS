﻿/*
 * Created by z.c. on 2010/10.
 * Modified by z.c. on 2010/10 - 2012/03.
 * Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 */


package com.crossdial.henapad_paid;
import com.crossdial.henapad_paid.KeyboardViewEx;
import com.crossdial.henapad_paid.TouchLine;
import com.crossdial.henapad_paid.LatinKeyboard.LatinKey;
import com.crossdial.henapad_paid.R;

import java.util.ArrayList;
import java.util.List;



import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.Keyboard.Key;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.inputmethod.EditorInfo;
import android.graphics.Rect;
import android.graphics.Paint.Align;
import com.crossdial.henapad_paid.R;

public class LatinKeyboardView extends KeyboardViewEx {
    

	int []countAction = null;
	int nCountAction = 0;
	int nCountElseAction = 0;
	int lastUp = 0;
	int lastDown = 0;
	
	private SameTime m_sametime;

	private ParkKeyboard mService;
    private Paint   mPaintT;
    
    private ArrayList<String> m_dragWordList;
    private ArrayList<String> m_dragWordListX;

    boolean isTouchMove = false;
    
    private List<Key> mKeys = null;
    private TouchLine m_TouchLines = null; 
    
    private void init() 
    {
		mPaintT = new Paint();
        mPaintT.setAntiAlias(true);
        mPaintT.setColor(0xFFFFFFFF);
        mPaintT.setTextSize(12);
        mPaintT.setTextAlign(Align.LEFT);
        
		String dragList;
		dragList = TextProc.xLoad_File2String(getContext().getResources(), R.raw.dragwordlist); //this.getResources()
		m_dragWordList = new ArrayList<String>();
		m_dragWordListX = new ArrayList<String>();
		TextProc.getWordArray(dragList, m_dragWordList, m_dragWordListX);
        
		m_TouchLines = new TouchLine();
		m_TouchLines.delegate = this;
		
		countAction = new int [MotionEvent.ACTION_MASK+1];
		for(int i = 0; i < countAction.length; i++)
		{
			countAction[i] = 0;
		}	
		
        m_sametime = new SameTime(this.getResources());

    }
    
    public LatinKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LatinKeyboardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    @Override
    protected boolean onLongPress(Key key) {
       	Logx.d("crossdial", "LatinKeyboardView::onLongPress");  
       	m_TouchLines.touch_up(0, MotionEvent.ACTION_UP);
       if (key.codes[0] == Keyboard.KEYCODE_CANCEL) {
            getOnKeyboardActionListener().onKey(KEYCODE_OPTIONS, null);
            return true;
        } else {
            return super.onLongPress(key);
        }
    }
    
    @Override
    public void onDraw(Canvas canvas) {
       	Logx.d("crossdial", ">>> LatinKeyboardView::onDraw");  

       	// super.onDraw(canvas);
       	LatinKey key;
       	List<Key>Keys = this.getKeyboard().getKeys();

       	int kbdPaddingLeft, kbdPaddingTop;
		kbdPaddingLeft = this.getPaddingLeft();
		kbdPaddingTop = this.getPaddingTop();
       	for(int i = 0; i < Keys.size(); i++)
       	{
       		key = (LatinKey)Keys.get(i);
       		if(key.icon != null)
       		{
       			canvas.translate(key.x + kbdPaddingLeft, key.y + kbdPaddingTop);
				key.icon.draw(canvas);
				canvas.translate(-key.x - kbdPaddingLeft, -key.y - kbdPaddingTop);
       		}
       	}

       	String label;
       	// down 이미지 그리기.
       	key = lastTouchKey;
       	int  drawableX = 0, drawableY = 0;
       	if(key != null)
		{
       		if(key.parentKey != null)
       			key = key.parentKey;
       		
       		Drawable pushImage = key.downImage;
       		if(pushImage != null)
       		{
				
				Rect padding = new Rect(0, kbdPaddingTop, 0,0);
				canvas.translate(key.x + kbdPaddingLeft, key.y + kbdPaddingTop);
				
				drawableX = (key.width - padding.left - padding.right 
						- key.icon.getIntrinsicWidth()) / 2 + padding.left;
				drawableY = (key.height - padding.top - padding.bottom 
						- key.icon.getIntrinsicHeight()) / 2 + padding.top;
				
				// canvas.translate(drawableX, drawableY);
				Rect rt = new Rect(key.icon.getBounds());
				rt.top++;
				
				pushImage.setBounds(rt);
				pushImage.draw(canvas);
				// canvas.translate(-drawableX, -drawableY);
				canvas.translate(-key.x - kbdPaddingLeft, -key.y - kbdPaddingTop);
				if( ParkKeyboard.DEBUG ) {
		        label = String.format("keyX=%d, keyY=%d, keyW = %d, keyH = %d"
		        		, key.x, key.y, key.width, key.height);
		        canvas.drawText(label,
		        		1,60, mPaintT);
		        label = String.format("iconX=%d, iconY=%d, iconW = %d, iconH = %d"
		        		, rt.left, rt.top, rt.width(), rt.height());
		        canvas.drawText(label,
		        		1,120, mPaintT);
				}
       		}
		}

       	m_TouchLines.onDraw(canvas);
        
       	printTouchEventInfo(canvas);
		if( ParkKeyboard.DEBUG ) {       	
		label = String.format("displayWidth = %d, left = %d, top=%d, drawableX = %d, drawableY = %d"
				, LatinKey.displayWidth
				,kbdPaddingLeft
				,kbdPaddingTop
				,drawableX
				,drawableY
	              );
        canvas.drawText(label,
        		 1,20, mPaintT);
        label = String.format("lastX=%f, lastY=%f"
        		, lastX, lastY);
        canvas.drawText(label,
        		1,200, mPaintT);
        }
        Logx.d("crossdial", "<<< LatinKeyboardView::onDraw");  
    }
    
    @Override 
    public void setKeyboard(Keyboard keyboard)
    {
    	super.setKeyboard(keyboard);
    	LatinKeyboard latin = (LatinKeyboard)keyboard;
    	
    	if(mService != null)
    	{
	    	EditorInfo ei;
	    	ei = mService.getCurrentInputEditorInfo();
	    	if(ei != null)
	    		latin.setImeOptions(getContext().getResources(), ei.imeOptions);
    	}
    }
    public void setService(ParkKeyboard listener) {
        mService = listener;
        m_sametime.keyView = mService;
    }
    
    private void printTouchEventInfo(Canvas canvas)
    {
    	if( !ParkKeyboard.DEBUG ) return;
     	/**
       	 * 터치 이벤트를 조사하기 위하여.
       	 */
		String label;
		label = String.format("Down=%d, Up=%d, Pt down=%d, up=%d, L down=%d, up=%d"
				, countAction[MotionEvent.ACTION_DOWN]
				, countAction[MotionEvent.ACTION_UP]
              , countAction[MotionEvent.ACTION_POINTER_DOWN]
              , countAction[MotionEvent.ACTION_POINTER_UP]
              , lastDown
              , lastUp
                            );
        canvas.drawText(label,
                1,20, mPaintT);
 
        label = String.format("All=%d, Else=%d move=%d, cancel=%d, out=%d"
        		,nCountAction
        		,nCountElseAction
		, countAction[MotionEvent.ACTION_MOVE]
		, countAction[MotionEvent.ACTION_CANCEL]
		, countAction[MotionEvent.ACTION_OUTSIDE]
	);
        label = String.format("width=%d, MeasuredWidth=%d left=%d"
        		, getWidth(), getMeasuredWidth(), getLeft());
        canvas.drawText(label,
        		1,100, mPaintT);  
        label = String.format("lastX=%f, lastY=%f"
        		, lastX, lastY);
        canvas.drawText(label,
        		1,200, mPaintT);  
    }
    
    private void testTouchEventInfo(MotionEvent event)
    {
    	if( !ParkKeyboard.DEBUG ) return;
    	int action = event.getAction();
       	/**
       	 * 터치 이벤트를 조사하기 위하여.
       	 */
    	countAction[action & MotionEvent.ACTION_MASK]++;
    	nCountAction++;
    	switch(action & MotionEvent.ACTION_MASK)
    	{
    	case MotionEvent.ACTION_DOWN:
    	case MotionEvent.ACTION_MOVE:
    	case MotionEvent.ACTION_UP:
    	case MotionEvent.ACTION_OUTSIDE:
    	case MotionEvent.ACTION_CANCEL:
    		break;
    	case MotionEvent.ACTION_POINTER_DOWN:
    		lastDown = action & MotionEvent.ACTION_POINTER_ID_MASK;
    		lastDown /= 256;
    		break;
    	case MotionEvent.ACTION_POINTER_UP:
    		lastUp = action & MotionEvent.ACTION_POINTER_ID_MASK;
    		lastUp /= 256;
    		break;
    	default:
    		nCountElseAction++;
    		break;
    	}
    	return ;
    	
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) 
    {
    	testTouchEventInfo(event);

    	if(mMiniKeyboardOnScreen) return true;
    	float x = event.getX();
        float y = event.getY();

        boolean bIgnore = false;
        m_TouchLines.onTouchEvent(event);

        String str;
        str = String.format(">>> LatinKeyboardView::onTouchEvent x=%d, y=%d action=%X", (int)x, (int)y, event.getAction());
        Logx.d("crossdial", str);  
        
        if (lastTouchKey != null) {
        	lastTouchKey.codes[0] = lastCode;
        	lastTouchKey.text = null;
        }
        
        LatinKey curKey = (LatinKey)lastTouchKey;
        switch (event.getAction()) 
        {
        case MotionEvent.ACTION_DOWN:
        	mCurrentKey = checkKeyIndex(x,y, true);
        	mKeys = this.getKeyboard().getKeys();
        	if(mCurrentKey >= 0)
        	{
        		curKey = (LatinKey)mKeys.get(mCurrentKey);
        		m_sametime.RegionDown(curKey.mainChar, curKey);
        	}
        	break;

        case MotionEvent.ACTION_MOVE:
        	isTouchMove = true;
        	break;
        
        case MotionEvent.ACTION_UP:
        	Logx.d("crossdial", " LatinKeyboardView::onTouchEvent ACTION_UP 1");  
        	if(lastTouchKey == null) // no key pressed! 
        		break;
        	
        	int[] keyCodes = lastTouchKey.codes;
        	if (curKey != null) {
        		if(curKey.mainChar >= 0) {
        			keyCodes[0] = curKey.mainChar;
        		}

        		if(this.isShifted() && curKey.shiftChar > 0)
        		{
        			keyCodes[0] = curKey.shiftChar;
        		}
        	}
        	
        	boolean bDragKey = false;
        	if (isTouchMove) 
        	{
        		int deletaY = (int)(y-lastY);
        		if(deletaY < 0) deletaY = -deletaY;
        		int deletaX = (int)(x-lastX);
        		if(deletaX < 0) deletaX = -deletaX;
        		// 아래우 이동을 판단하는 부분.
               	if (curKey.dragUpChar >= 0 && (y - lastY) < -FIRE_THRESHOLD && deletaX < FIRE_THRESHOLD_X_MAX) {
               		if(curKey.y - y < FIRE_THRESHOLD_OUT_Y_MAX) {
               			curKey.codes[0] = curKey.dragUpChar;
	        			bDragKey = true;
               		}
        		}
               	
        		if (curKey.dragDownChar >= 0 && (y - lastY) > FIRE_THRESHOLD && deletaX < FIRE_THRESHOLD_X_MAX) {
        			if(y - (curKey.y + curKey.height) < FIRE_THRESHOLD_OUT_Y_MAX) {
        				curKey.codes[0] = curKey.dragDownChar;
	        			bDragKey = true;
        			}
        		}
        		
        		// 좌우이동을 판단하는 부분.
               	if (curKey.dragLeftChar >= 0 && (x - lastX) < -FIRE_THRESHOLD && deletaY < FIRE_THRESHOLD_Y_MAX) {
               		if(curKey.x - x < FIRE_THRESHOLD_OUT_X_MAX) {
               			curKey.codes[0] = curKey.dragLeftChar;
	        			bDragKey = true;
               		}
        		}
        		if (curKey.dragRightChar >= 0 && (x - lastX) > FIRE_THRESHOLD && deletaY < FIRE_THRESHOLD_Y_MAX) {
        			if(x - (curKey.x + curKey.width) < FIRE_THRESHOLD_OUT_X_MAX) {
        				curKey.codes[0] = curKey.dragRightChar;
	        			bDragKey = true;
        			}
        		}
        		
        		if (curKey.codes[0] != lastCode) {
        			lastTouchKey.onReleased(true);
        		}

        		isTouchMove = false;
        	}

        	bIgnore = m_sametime.RegionUp(curKey);
        	
        	// mService.onKey(keyCodes[0], keyCodes);
        	
        	lastTouchKey = null;
        	
        	if(!bDragKey)
        	{
        		bIgnore = checkDragString();
        	}
        	break;
        }
        
        Logx.d("crossdial", " LatinKeyboardView::onTouchEvent before super");  
        boolean r = true;
        if(!bIgnore)
        	r = super.onTouchEvent(event);
        else
        {
    		mHandler.removeMessages(MSG_SHOW_PREVIEW);
    		mHandler.removeMessages(MSG_REPEAT);
    		mHandler.removeMessages(MSG_LONGPRESS);
    		
            showPreview(NOT_A_KEY);
        }
       	Logx.d("crossdial", "<<< LatinKeyboardView::onTouchEvent");  
       	invalidate();

        return r;
    }

    private boolean checkDragString()
    {
    	boolean validDrag = false;
    	/*
    	 * 드래그에 의한 입력이 구성되는가를 확인한다.
    	 */
    	String word = null, drag = "";
    	
    	int candIdx, idx = m_TouchLines.m_lastTouchedPathIndex;
    	if(idx >= 0)
    	{
    		drag = m_TouchLines.dragString[idx].substring(0);
    	}
    	if(drag.length() >= 2)
    	{
    	
    		int first, second;
    		first = drag.charAt(0);
    		second = drag.charAt(drag.length()-1);
    		if ( TextProc.isKoreanJamo(first, second) )
    		{
	        	mService.onKey(first, null);        		
    			mService.onKey(second, null);  
    			validDrag = true;
    		}
    		
    		candIdx = TextProc.findCandidate(drag, m_dragWordList);
    		
    		// 영문에서 무조건 드래그 성공시킨다. 2011.12.17
    		if(candIdx < 0)
    		{
    			if(mService.getCurrentKeyboardType() == ParkKeyboard.KEYBOARD_TYPE_ENGLISH12
    					|| mService.getCurrentKeyboardType() == ParkKeyboard.KEYBOARD_TYPE_CHINESE12)
    			{
    				word = String.format("%c%c", first, second);
    			}
    		}
    		
    		if( (!validDrag && candIdx >= 0) || word != null)
    		{
    			validDrag = true;
    			if(word == null)
    				word = m_dragWordListX.get(candIdx);
    			
    			// 드래그 처리 한다.
    			if(mService.getCurrentKeyboardType() == ParkKeyboard.KEYBOARD_TYPE_KOREAN12
    					||  mService.getCurrentKeyboardType() == ParkKeyboard.KEYBOARD_TYPE_CHINESE12)
    			{
    				for(int i = 0; i < word.length(); i++){
    					mService.onKey(word.charAt(i), null);
    				}
    			}
    			else
    			{
    				String codes = null;
    				
    	        	if (mService.m_shiftMode == 2) {
    	        		codes = word.toUpperCase();
    	        	}
    	        	else if (mService.m_shiftMode == 0)
    	        	{
    	        		codes = word.toLowerCase();
    	        	}
    	        	else if (mService.m_shiftMode == 1)
    	        	{
    	        		codes = String.format("%c%s", word.charAt(0), word.toLowerCase().substring(1));
    	        	}
    	        	
    	        	if(codes != null)
    	        		mService.onText(codes);
    			}
    		}
    	}
    	return validDrag;
    }
}
