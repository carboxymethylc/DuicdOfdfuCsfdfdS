﻿/*
 *  Modified by z on 2010/10 - 2010/11.
 *  Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 * 
 */

package com.crossdial.henapad_paid;

import com.crossdial.henapad_paid.LatinKeyboard.LatinKey;

import java.util.List;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.inputmethodservice.Keyboard.Key;
import android.view.MotionEvent;
import android.widget.Toast;
import android.view.View;


public class TouchLine {
	static class TouchPath
	{
		Path m_Path;
		float m_fX, m_fY;
		int m_nIndex;
		
		public TouchPath()
		{
			m_Path = new Path();
			m_fX = -1;
			m_fY = -1;
			m_nIndex = -1;
		}
	};
	
	private static final int	POINTER_MAX			= 2;
	
	private static final int	ACTION_DOWN			= 0;
	private static final int	ACTION_UP			= 1;
	private static final int	ACTION_POINTER_DOWN	= 2;
	private static final int	ACTION_POINTER_UP	= 3;
	
	private Paint m_Paint;
	public StringBuilder[] dragString = null;
	private TouchPath[] m_TouchPath;
	public int m_lastTouchedPathIndex = 0;
	
	public View view = null;
	public LatinKeyboardView delegate = null;
	public TouchLine()
	{
		
		m_Paint = new Paint();
        m_Paint.setColor(0xFFFF0000);
        m_Paint.setStyle(Paint.Style.STROKE);
        m_Paint.setStrokeJoin(Paint.Join.ROUND);
        m_Paint.setStrokeCap(Paint.Cap.ROUND);
        m_Paint.setStrokeWidth(20);
        
        m_TouchPath = new TouchPath[POINTER_MAX];
        dragString = new StringBuilder[POINTER_MAX];
        for (int i = 0; i < POINTER_MAX; i++)
        {
        	dragString[i] = new StringBuilder(10);
        	m_TouchPath[i] = new TouchPath();		
        }
	}

	/*	  기능	:	터치 움직임을 보여준다.
	 * 작성날자	:	2010-10-19 AM 00:37            */
	public void onDraw(Canvas canvas)
	{
		int i;
		
		for (i = 0; i < POINTER_MAX; i++)
		{
			if (m_TouchPath[i].m_nIndex != -1)
				canvas.drawPath(m_TouchPath[i].m_Path, m_Paint);
		}
	}
	
	private void tryAddDragChar(float x, float y, int pathIdx)
	{
		if(pathIdx != m_lastTouchedPathIndex)
		{
			pathIdx = m_lastTouchedPathIndex;
			Logx.e("crossdial", String.format("\n drag error ~~~~~ pathIdx(=%d) != m_lastTouchedPathIndex(=%d)", pathIdx, m_lastTouchedPathIndex));
		}
		
		int ch = getKeyChar(x, y);
		if(ch <= 0) return;
		
		int len = dragString[pathIdx].length();
		int last = 0;
		if(len > 0)
		{
			last = dragString[pathIdx].charAt(len-1);
		}
		if( last != ch )
		{
			dragString[pathIdx].append(String.format("%C", ch));
			Logx.i("crossdial", String.format("\n drag ~~~~~~~~~~~ dragString[%d] = %s", pathIdx, dragString[pathIdx]));
		}
	}
	
	private int getKeyChar(float x, float y)
	{
		int ch = 0;
		LatinKey key;
	   	List<Key> keys = delegate.getKeyboard().getKeys();
	   	int idx = delegate.checkKeyIndex(x, y, false);

	   	if(idx != -1) // NOT_A_KEY
	   	{
	   		key = (LatinKey)keys.get(idx);
	   		
	   		ch = Character.toUpperCase(key.mainChar);
	   	}
		return ch;
	}

	/*	  기능	:	터치 시작좌표를 얻는다.
	 * 작성날자	:	2010-10-19 AM 00:37            */
    private void touch_start(float x, float y, int p_nActionType)
    {
    	
    	switch (p_nActionType)
    	{
    	case ACTION_DOWN:
    		
    		m_TouchPath[POINTER_MAX-1].m_nIndex = -1;
    		m_TouchPath[0].m_nIndex = 0;
    		m_TouchPath[0].m_Path.reset();
    		m_TouchPath[0].m_Path.moveTo(x, y);
	        m_TouchPath[0].m_fX = x;
	        m_TouchPath[0].m_fY = y;
	        m_lastTouchedPathIndex = 0;
	        dragString[0].setLength(0);
			Logx.i("crossdial", String.format("\n drag ! dragString[%d] = %s", m_lastTouchedPathIndex, dragString[m_lastTouchedPathIndex]));

    		break;
    		
    	case ACTION_POINTER_DOWN:
    		int i;
    		
    		for (i = 0; i < POINTER_MAX; i++)
    		{
    			if (m_TouchPath[i].m_nIndex == -1)
    			{
    				m_TouchPath[POINTER_MAX-1-i].m_nIndex = -1;
    				m_TouchPath[i].m_nIndex = 1;
    		    	m_TouchPath[i].m_Path.reset();
    		    	m_TouchPath[i].m_Path.moveTo(x, y);
    		        m_TouchPath[i].m_fX = x;
    		        m_TouchPath[i].m_fY = y;
    		        m_lastTouchedPathIndex = i;
    		        dragString[i].setLength(0);
    		        Logx.i("crossdial", String.format("\n drag ! dragString[%d] = %s", m_lastTouchedPathIndex, dragString[m_lastTouchedPathIndex]));
    				break;
    			}
    		}
    		break;
    	}
    }
    
	/*	  기능	:	터치움직임 좌표들을 얻어 맺어준다.
	 * 작성날자	:	2010-10-19 AM 00:37            */
    private void touch_move(float x, float y, int p_nPointerIdx)
    {
    	int i;
    	
    	for (i = 0; i < POINTER_MAX; i++)
    	{
    		if (m_TouchPath[i].m_nIndex == p_nPointerIdx)
    		{
    			TouchPath path = m_TouchPath[i];
    	        // float dx = Math.abs(x - path.m_fX);
    	        // float dy = Math.abs(y - path.m_fY);
    	        
	        	path.m_Path.lineTo(x, y);
	        	path.m_fX = x;
	        	path.m_fY = y;
	        	m_lastTouchedPathIndex = i;
    		}
    	}
    }
    
	/*	  기능	:	터치끝좌표를 얻어 맺어준다. 
	 * 작성날자	:	2010-10-19 AM 00:37            */
    public void touch_up(int p_nPointerIdx, int p_nActionType)
    {
    	int i;
    	
    	switch (p_nActionType)
    	{
    	case ACTION_UP:
    		for (i = 0; i < POINTER_MAX; i++)
    		{
    			if (m_TouchPath[i].m_nIndex == p_nPointerIdx)
    			{
	    			m_TouchPath[i].m_Path.reset();
	    			m_TouchPath[i].m_nIndex = -1;
	    			m_TouchPath[1-i].m_nIndex = -1;
	    			m_TouchPath[i].m_fX= -1;
	    			m_TouchPath[i].m_fY= -1;
	    			m_lastTouchedPathIndex = i;
    			}
    		}
    		break;
    	case ACTION_POINTER_UP:
    		for (i = 0; i < POINTER_MAX; i++)
    		{
    			if (m_TouchPath[i].m_nIndex == p_nPointerIdx)
    			{
    				m_TouchPath[i].m_nIndex = -1;
    				m_TouchPath[POINTER_MAX-1-i].m_nIndex = -1;
    				m_TouchPath[i].m_Path.reset();
    				m_TouchPath[i].m_fX= -1;
        			m_TouchPath[i].m_fY= -1;
        			m_lastTouchedPathIndex = i;
    			}
    			else
    			{
    				// m_TouchPath[i].m_nIndex = 0;
    			}
    		}
    	}
    }

    /**
     * 터치사건은 처리하여 터치라인을 그린다. 
     */
    public boolean onTouchEvent(MotionEvent event)
	{
		final int action = event.getAction();
		int nPointerIndex;
		// nPointerIndex = findTouchIndex(event); 일단 보류한다.
		
		switch (action & MotionEvent.ACTION_MASK)
		{
		case MotionEvent.ACTION_DOWN:
			touch_start(event.getX(0), event.getY(0), ACTION_DOWN);
			break;

		case MotionEvent.ACTION_MOVE:
			int i;
			for (i = 0; i < event.getPointerCount(); i++)
			{
				if(i >= POINTER_MAX) continue;
				if (m_TouchPath[i].m_nIndex != -1)
				{
					if (m_TouchPath[i].m_nIndex < event.getPointerCount())
					{
						touch_move(event.getX(m_TouchPath[i].m_nIndex),
								   event.getY(m_TouchPath[i].m_nIndex),
								   m_TouchPath[i].m_nIndex);
					}
				}
			}
			break;
		
		case MotionEvent.ACTION_UP:
			touch_up(0, ACTION_UP);
			break;
		
		case MotionEvent.ACTION_POINTER_DOWN:
			nPointerIndex = (action & MotionEvent.ACTION_POINTER_ID_MASK)
							>> MotionEvent.ACTION_POINTER_ID_SHIFT;
			if (1 < event.getPointerCount())
			{
				touch_start(event.getX(1), event.getY(1), ACTION_POINTER_DOWN);
			}
			break;

		case MotionEvent.ACTION_POINTER_UP:
			nPointerIndex = (action & MotionEvent.ACTION_POINTER_ID_MASK)  
							>> MotionEvent.ACTION_POINTER_ID_SHIFT;
			touch_up(nPointerIndex, ACTION_POINTER_UP);
			break;

		case MotionEvent.ACTION_CANCEL:
			Toast.makeText(view.getContext(), "ACTION_CANCEL", Toast.LENGTH_SHORT).show();
			break;
			default:
				return true;
		}

		tryAddDragChar(event.getX(0), event.getY(0), m_lastTouchedPathIndex);//nPointerIndex
		return true;
	}
    
    public int findTouchIndex(MotionEvent event)
    {
    	float x = event.getX();
        float y = event.getY();
        float preX, preY; 
        if(event.getHistorySize() > 0)
        {
        	preX = event.getHistoricalX(0);
        	preY = event.getHistoricalY(0);
        }
        else
        {
        	preX = x;
        	preY = y;
        }

    	int idx = 0;
    	float min_dist = 10000000;
    	float dist;
    	for(int i = 0; i < m_TouchPath.length; i++)
    	{
    		if(m_TouchPath[i].m_nIndex == -1) continue;
    		dist = (m_TouchPath[i].m_fX - preX)*(m_TouchPath[i].m_fX - preX) + (m_TouchPath[i].m_fY - preY)*(m_TouchPath[i].m_fY - preY);
    		if(min_dist > dist)
    		{
    			min_dist = dist;
    			idx = i;
    		}
    	}
    	return idx;
    }
}
