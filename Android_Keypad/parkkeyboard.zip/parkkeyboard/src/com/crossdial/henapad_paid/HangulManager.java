﻿/*	
 * Hangul input manager class.
 *  Created by z.c on 2010/10/26.
 *  Modified by z.c. on 2010/10 - 2012/03.
 *  Copyright 2010 Cross Dial Technologies. All rights reserved.
 */

package com.crossdial.henapad_paid;

import java.lang.StringBuilder;

public class HangulManager {

	public final int	VAL_INVALID = 0xFF;

	public StringBuilder mComposing = null;
	boolean isComposite;
	int comFirst;
	int comMid;
	int comLast;
	
	public HangulManager() {
		txtInputList = new StringBuilder();
	}
	
	StringBuilder txtInputList = null;
	
	//id<KeyboardDelegate> delegate;
	public ParkKeyboard delegate;
	
	static int  DOUBLE_JAUM = 0;
	
	// 20 또는 12+14 자판을 위한 모음+모음=모음
	static final int  midCompositeTable[][] = {
		{  1, 21,  2 },		// ㅏ + ㅣ = ㅐ
		{  1,  1,  3 },		// ㅏ + ㅏ = ㅑ
		{  2,  2,  4 },		// ㅐ + ㅐ = ㅒ
		{  2, 21,  4 },		// ㅐ + ㅣ = ㅒ
		{  3, 21,  4 },		// ㅑ + ㅣ = ㅒ
		{  5, 21,  6 },		// ㅓ + ㅣ = ㅔ
		{  5,  5,  7 },		// ㅓ + ㅓ = ㅕ
		{  6,  6,  8 },		// ㅔ + ㅔ = ㅖ
		{  6, 21,  8 },		// ㅔ + ㅣ = ㅖ
		{  7, 21,  8 },		// ㅕ + ㅣ = ㅖ
		{  9,  1, 10 }, 	// ㅗ + ㅏ = ㅘ
		{ 10, 21, 11 }, 	// ㅘ + ㅣ = ㅙ
		{  9,  2, 11 }, 	// ㅗ + ㅐ = ㅙ
		{  9, 21, 12 }, 	// ㅗ + ㅣ = ㅚ 
		{  9,  9, 13 }, 	// ㅗ + ㅗ = ㅛ
		{ 14,  5, 15 }, 	// ㅜ + ㅓ = ㅝ
		{ 15, 21, 16 }, 	// ㅝ + ㅣ = ㅞ
		{ 14,  6, 16 }, 	// ㅜ + ㅔ = ㅞ
		{ 14, 21, 17 }, 	// ㅜ + ㅣ = ㅟ
		{ 14, 14, 18 }, 	// ㅜ + ㅜ = ㅠ
		{ 19, 21, 20 }, 	// ㅡ + ㅣ = ㅢ
		
		{ -1, -1, -1 }
	};
	
	//받침+받침=받침 조합
	static final int compositeLastTable[][] = {
		{  1, 19,  3 },		// ㄱ+ㅅ=ㄳ
		{  4, 22,  5 },		// ㄴ+ㅈ=ㄵ
		{  4, 27,  6 },		// ㄴ+ㅎ=ㄶ
		{  8,  1,  9 },		// ㄹ+ㄱ=ㄺ
		{  8, 16, 10 },		// ㄹ+ㅁ=ㄻ
		{  8, 17, 11 },		// ㄹ+ㅂ=ㄼ
		{  8, 19, 12 },		// ㄹ+ㅅ=ㄽ
		{  8, 25, 13 },		// ㄹ+ㅌ=ㄾ
		{  8, 26, 14 },		// ㄹ+ㅍ=ㄿ
		{  8, 27, 15 },		// ㄹ+ㅎ=ㅀ
		{ 17, 19, 18 },		// ㅂ+ㅅ=ㅄ
		// { 19, 19, 20 },		// ㅅ+ㅅ=ㅆ
		// {  1,  1,  2 },		// ㄱ+ㄱ=ㄲ
		{ -1, -1, -1 }		// 
	};
	
	// 자음+자음=자음.  이표는 ㅅ+ㅅ=ㅆ에만 사용하던지. 아니면 없애던지.
	static final int compositeFirstTable[][] = {
		{ 1, 1, 2 },	//ㄱ+ㄱ=ㄲ
		{ 4, 4, 5 },	//ㄷ+ㄷ=ㄸ
		{ 10, 10, 11 }, //ㅅ+ㅅ=ㅆ
		{ 13, 13, 14 }, //ㅈ+ㅈ=ㅉ
		{ 8, 8, 9 },	//ㅂ+ㅂ=ㅃ
		{ -1, -1, -1}
	};
	
	// 자음을 밭침을 옮기는 표
	static final int firstToLastTable[][] = {
		{  1,  1 },		// ㄱ
		{  2,  2 },		// ㄲ
		{  3,  4 },		// ㄴ
		{  4,  7 },		// ㄷ
		{  5,  0 },		// ㄸ
		{  6,  8 },		// ㄹ
		{  7, 16 },		// ㅁ
		{  8, 17 },		// ㅂ
		{  9,  0 },		// ㅃ
		{ 10, 19 },		// ㅅ
		{ 11, 20 },		// ㅆ
		{ 12, 21 },		// ㅇ
		{ 13, 22 },		// ㅈ
		{ 14,  0 },		// ㅉ
		{ 15, 23 },		// ㅊ
		{ 16, 24 },		// ㅋ
		{ 17, 25 },		// ㅌ
		{ 18, 26 },		// ㅍ
		{ 19, 27 },		// ㅎ
		{ -1, -1 }		// ㅎ
	};
	
	
	// 자음을 밭침을 옮기는 표
	static final int lastTofirstTable[][] = {
		{ 1 ,  1 },		// ㄱ
		{ 2 ,  2 },		// ㄲ
		{ 3 , -1 },
		{ 4 ,  3 },		// ㄴ
		{ 5 , -1 },
		{ 6 , -1 },
		{ 7 ,  4 },		// ㄷ
		{ 8 ,  6 },		// ㄹ
		{ 9 , -1 },
		{10 , -1 },
		{11 , -1 },
		{12 , -1 },
		{13 , -1 },
		{14 , -1 },
		{15 , -1 },
		{16 ,  7 },		// ㅁ
		{17 ,  8 },		// ㅂ
		{18 , -1 },
		{19 , 10 },		// ㅅ
		{20 , 11 },		// ㅆ
		{21 , 12 },		// ㅇ
		{22 , 13 },		// ㅈ
		{23 , 15 },		// ㅊ
		{24 , 16 },		// ㅋ
		{25 , 17 },		// ㅌ
		{26 , 18 },		// ㅍ
		{27 , 19 }		// ㅎ
		
	};
	
	// 호환 자모를 자모번호로!
	static final int hohwanTofirstLastTable[][] = {
		{ 1 ,  1 ,  1},		// ㄱ
		{ 2 ,  2 ,  2},		// ㄲ
		{ 3 , -1 ,  3},		// ㄳ
		{ 4 ,  3 ,  4},		// ㄴ
		{ 5 , -1 ,  5},		// ㄵ
		{ 6 , -1 ,  6},		// ㄶ
		{ 7 ,  4 ,  7},		// ㄷ
		{ 8 ,  5 , -1},		// ㄸ
		{ 9 ,  6 ,  8},		// ㄹ
		{10 , -1 ,  9},		// ㄺ
		{11 , -1 , 10},		// ㄻ
		{12 , -1 , 11},		// ㄼ
		{13 , -1 , 12},		// ㄽ
		{14 , -1 , 13},		// ㄾ
		{15 , -1 , 14},		// ㄿ
		{16 , -1 , 15},		// ㅀ	
		{17 ,  7 , 16},		// ㅁ
		{18 ,  8 , 17},		// ㅂ
		{19 ,  9 , -1},		// ㅃ
		{20 , -1 , 18},		// ㅄ
		{21 , 10 , 19},		// ㅅ
		{22 , 11 , 20},		// ㅆ
		{23 , 12 , 21},		// ㅇ
		{24 , 13 , 22},		// ㅈ
		{25 , 14 , -1},		// ㅉ
		{26 , 15 , 23},		// ㅊ
		{27 , 16 , 24},		// ㅋ
		{28 , 17 , 25},		// ㅌ
		{29 , 18 , 26},		// ㅍ
		{30 , 19 , 27}		// ㅎ
		//@"ㄱㄲㄳㄴㄵㄶㄷㄸㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅃㅄㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
	};
	
	// 받침->받침+자음 (받침+모음 조합시 사용. 0 은 받침 없음을 의미한다!
	static final int extractLastTable[][] = {
		{  0,  1 },		//  +ㄱ
		{  0,  2 },		//  +ㄲ
		{  1, 10 },		// ㄱ+ㅅ
		{  0,  3 },		//  +ㄴ
		{  4, 13 },		// ㄴ+ㅈ
		{  4, 19 },		// ㄴ+ㅎ
		{  0,  4 },		//  +ㄷ
		{  0,  6 },		//  +ㄹ
		{  8,  1 },		// ㄹ+ㄱ
		{  8,  7 },		// ㄹ+ㅁ
		{  8,  8 },		// ㄹ+ㅂ
		{  8, 10 },		// ㄹ+ㅅ
		{  8, 17 },		// ㄹ+ㅌ
		{  8, 18 },		// ㄹ+ㅍ
		{  8, 19 },		// ㄹ+ㅎ
		{  0,  7 },		//  +ㅁ
		{  0,  8 },		//  +ㅂ
		{ 17, 10 },		// ㅂ+ㅅ
		{  0, 10 },		//  +ㅅ
		//{ 19, 10 },		//  +ㅆ//
		{  0, 11 },		//  +ㅆ
		{  0, 12 },		//  +ㅇ
		{  0, 13 },		//  +ㅈ
		{  0, 15 },		//  +ㅊ
		{  0, 16 },		//  +ㅋ
		{  0, 17 },		//  +ㅌ
		{  0, 18 },		//  +ㅍ
		{  0, 19 },		//  +ㅎ
		{ -1, -1 }		//  +ㅎ
	};
	
	// 된자음 표
	static final int  doubleJaeumTable[][] = {
		{  1,  2 },		// ㄱ -> ㄲ
		{  4,  5 },		// ㄷ -> ㄸ
		{  8,  9 },		// ㅂ -> ㅃ
		{ 13, 14 },		// ㅈ -> ㅉ
		{ 10, 11 },		// ㅅ -> ㅆ
		{ -1, -1 }		// end.
	};
	
	int getHohwanJaumNoFromFirstNo(int ch)
	{
		for(int i = 0; i<30; i++)
		{
			if( hohwanTofirstLastTable[i][1] == ch )
				return hohwanTofirstLastTable[i][0];
		}
		return -1;
	}
	
	int getHohwanJaumNoFromLastNo(int ch)
	{
		for(int i = 0; i<30; i++)
		{
			if( hohwanTofirstLastTable[i][2] == ch )
				return hohwanTofirstLastTable[i][0];
		}
		return -1;
	}
	
	int getLastNoFromUniCode(int ch)
	{
		if (ch >= 0x3131 && ch <= 0x314E)  // 한글 호환 자음 30. (둘받침 ㄸ,ㅃ,ㅉ 포함)
		{
			return (int)hohwanTofirstLastTable[ch - 0x3131/* + 1*/][2];
		}
		return -1;
	}
	
	static public int getJaumNoFromUniCode(int ch)
	{
		if (ch >= 0x1100 && ch <= 0x1112) // 한글 자모 19. (자음)
		{
			return ch - 0x1100 + 1;
		}
		
		if (ch >= 0x11A8 && ch <= 0x11C2)  // 한글 자모 27. (받침)
		{
			return (int)lastTofirstTable[ch - 0x11A8/* + 1*/][1];
		}
		
		if (ch >= 0x3131 && ch <= 0x314E)  // 한글 호환 자음 30. (둘받침 ㄸ,ㅃ,ㅉ 포함)
		{
			return (int)hohwanTofirstLastTable[ch - 0x3131/* + 1*/][1];
		}
		
		return -1;
		
	}
	
	static public int getMoumNoFromUniCode(int ch)
	{
		if ( ch >= 0x1161 && ch <= 0x1175 ) // 21 모음
		{
			return ch - 0x1161 + 1;
		}
		if ( ch >= 0x314F && ch <= 0x3163 ) // 21 모음
		{
			return ch - 0x314F + 1;
		}
		return -1;
		
	}
	
	
	boolean decompositeKChar(int kChar, int [] element)
	{
		if(kChar >= 0xAC00 && kChar <= 0xD7A3)//'가' - '힣'
		{
			element[0] = (kChar - 0xAC00)/(21*28)+1;
			element[1] = ((kChar - 0xAC00)%(21*28))/28+1;
			element[2] = ((kChar - 0xAC00)%(21*28))%28;
			return true;
		}
		
		boolean ret = false;
		element[0] = element[1] = element[2] = 0;
		if(kChar >= 0x3131 && kChar <= 0x3163)
		{
			ret = true;
			if(getJaumNoFromUniCode(kChar) >=0 )
			{
				element[0] = getJaumNoFromUniCode(kChar);
			} 
			else if(getMoumNoFromUniCode(kChar) >=0 )
			{
				element[1] = getMoumNoFromUniCode(kChar);
			}
			else if(getLastNoFromUniCode(kChar) >=0 )
			{
				element[2] = getLastNoFromUniCode(kChar);
			}
		}
		
		// NSLog(@"decomposite first = %d, mid = %d, last = %d", element[0], element[1], element[2]);
		return ret;
		
	}
	
	// 결합 모음에서 덜기.
	int extractCompositeMid(int compositedMidCode, int mid)
	{
		if( compositedMidCode == mid )
		{
			return 0;
		}
		
		for (int i = 0; midCompositeTable[i][0] != -1; ++i) 
		{	
			if (compositedMidCode == midCompositeTable[i][2])
			{
				if( mid == midCompositeTable[i][1] )
				{
					return midCompositeTable[i][0];
				}
			}
		}
		
		return -1;
	}
	
	// 초성에서 자음 덜기.
	int extractCompositeFirst(int compositedFirstCode, int first)
	{
		if( compositedFirstCode == first )
		{
			return 0;
		}
		
		for (int i = 0; compositeFirstTable[i][0] != -1; ++i) 
		{	
			if (compositedFirstCode == compositeFirstTable[i][2])
			{
				if( first == compositeFirstTable[i][1] )
				{
					return compositeFirstTable[i][0];
				}
			}
		}
		
		return -1;
	}
	
	
	// 종성 결합하기.
	int compositeLastPartFirst(int last1, int last2)
	{
		for (int i = 0; compositeLastTable[i][0] >= 0; ++i) {
			if (compositeLastTable[i][0] == last1 && compositeLastTable[i][1] == last2) {
				return compositeLastTable[i][2];
			}
		}
		
		return -1;
	}
	
	// 종성+자음=종성 (삭제시)
	int compositeLastPartFirstOnRemove(int last1, int fisrt)
	{
		for (int i = 0; extractLastTable[i][0] >= 0; ++i) {
			if (extractLastTable[i][0] == last1 && extractLastTable[i][1] == fisrt) {
				return i+1;
			}
		}
		
		return -1;
	}
	
	int firstToLast(int first)
	{
		for (int i = 0; firstToLastTable[i][0] >= 0; ++i) {
			if (first == firstToLastTable[i][0]) {
				return firstToLastTable[i][1];
			}
		}
		return 0;
	}
	
	int lastToFirst(int last)
	{
		for (int i = 0; firstToLastTable[i][0] >= 0; ++i) {
			if (last == firstToLastTable[i][1]) {
				return firstToLastTable[i][0];
			}
		}
		return 0;
	}
	
	
	// 한글 합성하기.
	int makeUnicodeWithFirst(int first, int mid, int last)
	{
		int unicode = 0;
		
		if (first == 0 && mid == 0 && last == 0)
			return -1;
		
		if (first == 0) 
		{
			if(mid == 0x2022/*ㆍ*/ || mid == 0x318D/*•*/) 
			{
				unicode = 0x318D;//
			}
			else if(mid == 0x2025) 
			{
				unicode = 0x2025;//‥
			}
			else if (mid == 0)
			{
				if( getHohwanJaumNoFromLastNo(last) == -1 )
				{
					// NSLog(@" getHohwanJaumNoFromLastNo(last) == -1 -> last = %d", last);
					return -1;
				}
				unicode = 0x3131 + getHohwanJaumNoFromLastNo(last) - 1;
			}
			else
			{
				unicode = (0x314F + mid - 1);
			}
		} 
		else if (mid == 0) 
		{
			unicode = 0x3131 + getHohwanJaumNoFromFirstNo(first) - 1;
		} 
		else 
		{
			unicode = (0xAC00 + (first-1)*21*28 + (mid-1)*28 + last);
			// NSLog(@"makeUnicodeWithFirst >>> unicode = %C first-1, mid-1, last = %d, %d, %d", unicode, first-1, mid-1, last);
		}
		
		return unicode;
	}
	
	int getCompositedChar(int kChar, int fisrt )
	{
		if(kChar <= 0) 
			return -1;
		
		int [] element = new int[3];
		
		if ( !decompositeKChar(kChar, element) )
			return -1;
		
		if ( element[0] <= 0 || element[1] <= 0 )
			return -1;
		
		int compLast = compositeLastPartFirstOnRemove(element[2], fisrt);
		
		if( compLast == -1)
		{
			return -1;
		}
		
		return makeUnicodeWithFirst(element[0], element[1], compLast);
		
	}
	
	String getRemovedChar(int backBackChar, int backChar, int lastInsertChar)
	{
		if( !(lastInsertChar >= 0x3131 && lastInsertChar <= 0x3163) )
		{
			return null;
		}
		int hohwanNo = lastInsertChar - 0x3131 + 1;
		
		
		int [] element = new int [3];
		
		if( !decompositeKChar(backChar, element) )
		{
			return null;
		}
		
		boolean bEraseTwo = false;
		
		if( element[2] > 0 ) // 받침인 경우.
		{
			if ( element[2] == getLastNoFromUniCode(lastInsertChar) )//hohwanTofirstLastTable[hohwanNo-1][2] )
			{
				// 받침의 전체.
				element[2] = 0;
			}
			else if( extractLastTable[element[2]-1][1] == getJaumNoFromUniCode(lastInsertChar) )//hohwanTofirstLastTable[hohwanNo-1][1])
			{
				// 받침의 일부.
				element[2] = extractLastTable[element[2]-1][0];
			}
			else
			{
				///NSLog(@"받침 제거인데 오류 src = %d, dst = %C\n", element[2], lastInsertChar);
				return null;
			}
		}
		else if( element[1] > 0 ) // 모음인 경우.
		{
			int remainMidCode = -1;
			int midCode = hohwanNo-30;
			if( midCode >= 0 )
			{
				remainMidCode = extractCompositeMid(element[1], midCode);
			}
			if ( remainMidCode < 0 )
			{
				///NSLog(@"모음 제거인데 오류 src = %C, dst = %C\n", (int)0x314E + element[1], lastInsertChar);
				return null;
			}
			element[1] = remainMidCode;
			if( remainMidCode == 0 && element[0] > 0 && backBackChar > 0)
			{
				// 자음만 남았을때
				int kChar = getCompositedChar(backBackChar, element[0]);
				if( kChar > 0 )
				{
					// NSLog(@"이전의 이전 글자에 올라가 붇는 경우.");
					bEraseTwo = true;
					if( !decompositeKChar(kChar, element) )
					{
						///NSLog(@" !decompositeKChar(kChar, element) 실패.");
					}
				}
			}
		}
		else if( element[0] > 0 ) // 자음인 경우.
		{
			int remainFirstCode = -1;
			int firstCode = getJaumNoFromUniCode(lastInsertChar);//hohwanTofirstLastTable[hohwanNo-1][1];
			if( firstCode >= 0 )
			{
				remainFirstCode = extractCompositeFirst(element[0], firstCode);
			}
			if ( remainFirstCode < 0 )
			{
				///NSLog(@"초성 제거인데 오류 src = %C, dst = %C\n", 0x3130+element[0], lastInsertChar);
				element[0] = 0;
			}
			else
			{
				element[0] = remainFirstCode;
			}
			
		}
		else
		{
			// NSLog(@"0? \n");
			return null;
		}
		
		
		
		// 지울 문자를 합성한다.
		int erasedChar = makeUnicodeWithFirst(element[0], element[1], element[2]);
		String erasedString;
		
		if( erasedChar < 0)
		{
			// 지우기만 하면 되는 경우.
			erasedString = String.format("");
		}
		else if( bEraseTwo )
		{
			// 앞 글자가 이전으로 옮겨간 경우.
			erasedString = String.format("%C-", erasedChar);
		}
		else
		{
			erasedString = String.format("%C", erasedChar);
		}
		return erasedString;
	}
	
	int getDoubleJaeum(int jaeum)
	{
		for (int i = 0; doubleJaeumTable[i][0] >= 0; ++i) {
			if (jaeum == doubleJaeumTable[i][0]) {
				return doubleJaeumTable[i][1];
			}
		}
		return 0;	
	}
	
	/*
	 * 
 
	 */
	
//전각/반각 대응
	String getSBCCase(int ch){
		// ch는 한글 호환 자모의 유니코드 값이여야 한다. 0x3131~
		String value = String.format("%c", ch);
		return value;
	}
	
	void insertCh(int ch)
	{
		String insertChar = this.getSBCCase(ch);
		if (isComposite) {
			delegate.backAndInsert(insertChar);
		}
		else {
			delegate.insertText(insertChar);
		}
	}
	
	void setComData(int ch)
	{
		int [] element = new int [3];
		
		if( !decompositeKChar(ch, element) )
		{
			///NSLog(@" setComData : Can't decomposite Korean char = %d", ch);
			
			comFirst	= 0;
			comMid		= 0;
			comLast		= 0;
			return ;
		}
		
		comFirst	= element[0];
		comMid		= element[1];
		comLast		= element[2];
	}
	
	public boolean doErase()
	{
		// ///NSLog(@"doErase >>> text = <%@>", txtInputList);
		
		int backChar = delegate.getCurrentBackChar(1);
		int backBackChar = delegate.getCurrentBackChar(2);
		int lastInsertChar = -1;
		if(txtInputList.length() > 0)
			lastInsertChar = txtInputList.charAt(txtInputList.length()-1);
		if(txtInputList.length() < 3) // 2글자 이상 되려면.
		{
			backBackChar = -1;
		}
		String erasedString = getRemovedChar(backBackChar, backChar, lastInsertChar);
		
		if ( erasedString == null )
		{
			// ///NSLog(@"if ( erasedString == null )");
			this.clearComposite();
			this.endComposite();
			delegate.backAndInsert("");
		}
		else
		{
			txtInputList.delete(txtInputList.length()-1, txtInputList.length());
			if ( erasedString.length() == 0 )
			{
				this.setComData(backBackChar);
				delegate.backAndInsert("");
			}
			else if ( erasedString.length() == 1 )
			{
				this.setComData(erasedString.charAt(0));
				delegate.backAndInsert(erasedString);
			} 
			else if ( erasedString.length() == 2 )
			{
				String ins = erasedString.substring(0, 1);
				this.setComData(ins.charAt(0));
				delegate.backAndInsert("");
				delegate.backAndInsert(ins);
			}
			else
			{
				///NSLog(@" error ~~~~. ");
			}
		}
		
		return true;
	}
	
	public void clearComposite()
	{
		txtInputList.setLength(0);
	}
	
// 글자 완성 되었다.
	public void endComposite()
	{
		// ///NSLog(@" >>> endComposite >>> ");
		if (isComposite) {
			isComposite = false;
			comFirst = comMid = comLast = 0;
		}
		
		delegate.endComposing();
		if(mComposing != null)
			mComposing.setLength(0);
	}
	
	void insertComposite()
	{
		
		int unicode = makeUnicodeWithFirst(comFirst, comMid, comLast);
		
		if (unicode == 0) {
			
		} else {
			this.insertCh(unicode);
			
			isComposite = true;
		}
	}
	
	void insertCompositeExFirst(int first,int mid, int last)
	{
		if (first == VAL_INVALID)
			first = comFirst;
		if (mid   == VAL_INVALID)
			mid   = comMid;
		if (last  == VAL_INVALID)
			last  = comLast;
		
		comFirst	= first;
		comMid		= mid;
		comLast		= last;
		
		this.insertComposite();
		
	}
	
	
	public void IMEModeKorean(int key)// length = 1 !
	{
		/////NSLog(@"hangulManager.IMEModeKorean(<%@>)", key);
		int ch = 0;
		ch = key;// key.charAt(0);
		int no;
		String buf = String.format("%c", key);
		txtInputList.append(buf);
		
		if (ch != 0) 
		{
			if ( getJaumNoFromUniCode(ch) >= 0 )
			{
				no = getJaumNoFromUniCode(ch);
				this.automataForJaeumFirst( no );
			} 
			else if ( getMoumNoFromUniCode(ch) > 0 )// || ch == 0x318D /*천지음 'ㆍ'*/|| ch == 0x2025 /*천지음 '‥'*/) 
			{
				no = getMoumNoFromUniCode(ch);
				
				this.automataForMoeumMid( no );
			}
			else if(getLastNoFromUniCode(ch) > 0 ) // 둘받침 처리.
			{
				no = getLastNoFromUniCode(ch);
				if (comFirst != 0 && comMid != 0 && comLast == 0) //&& comMid !=0x202D && comMid != 0x2025)
				{
					// 받침으로 되는 경우
					this.insertCompositeExFirst(VAL_INVALID, VAL_INVALID, no);
				}
				else
				{
					this.endComposite();
					this.insertCompositeExFirst(0, 0, no);
				}
			}
			else // 완성글자들이 들어온 경우
			{
				this.endComposite();
				this.clearComposite();
				delegate.insertText(String.format("%c", ch));
			}
		}
	}
	
// 자음이 입력된 경우
	void automataForJaeumFirst(int first)
	{
		int last = firstToLast(first);
		
		boolean bProcessed = false;
		
		if (comLast != 0) 
		{
			// 받침+자음.
			bProcessed = true;
			int compositedLast = compositeLastPartFirst(comLast, last);
			
			if (compositedLast < 0) 
			{
				// 결합이 되지 않는 경우.
				this.endComposite();
				this.insertCompositeExFirst(first, 0, 0);
			} 
			else 
			{
				// 받침+자음이 결합된 경우.
				this.insertCompositeExFirst(VAL_INVALID, VAL_INVALID, compositedLast);
			}
		} 
		else if (comFirst != 0 && comMid != 0) //&& comMid !=0x202D && comMid != 0x2025)
		{
			// 자음+모음+자음
			bProcessed = true;
			if (last != 0) 
			{
				// 받침으로 되는 경우
				this.insertCompositeExFirst(VAL_INVALID, VAL_INVALID, last);
			}
			else 
			{
				// 새 글자의 자음으로 되는 경우
				this.endComposite();
				this.insertCompositeExFirst(first, 0, 0);
			}
		} 
		else  if (comFirst != 0 && comMid == 0)
		{
			// 자음+자음.
			int preLast = firstToLast(comFirst);
			
			// 된자음 입력 조사
			if ( DOUBLE_JAUM == 1 )
			{
				if(comFirst == first)
				{
					int jaum = getDoubleJaeum(first);
					if( jaum > 0 )
					{
						bProcessed = true;
						this.insertCompositeExFirst(jaum, 0, 0);
					}
				}
			}
			
			// 둘받침 가능성 조사.
			int compositedLast = compositeLastPartFirst(preLast, last);
			if( !bProcessed && preLast > 0 && last > 0 && compositedLast >= 0 )
			{
				// 둘받침.
				bProcessed = true;
				this.insertCompositeExFirst(0, 0, compositedLast);
			}
			
		}
		
		if( bProcessed == false )
		{
			// 모음+자음 등 처리되지 않은 경우는 새글자 자음으로 처리한다.
			this.endComposite();
			this.insertCompositeExFirst(first, 0, 0);
		}
	}
	
// 모음을 추가할 경우의 오토마타
	void automataForMoeumMid(int mid)
	{
		
		if (comLast != 0) 
		{
			// 받침+모음
			// 받침에서 자음 한개를 떼온다.
			int newFirst = extractCompositeLast(comLast, 1);
			comLast	= extractCompositeLast(comLast, 0);
			// 이전 글자를 제거한다.
			isComposite = true; //??
			this.insertComposite();
			this.endComposite();
			
			this.insertCompositeExFirst(newFirst, mid, 0);
		} 
		else if (comMid != 0) 
		{
			// 모음+모음
			int compositeMid = compositeMidPartFirst(comMid, mid);
			
			if (compositeMid == 0) 
			{
				// 겹모음이 될수 없는 경우.
				this.endComposite();
				this.insertCompositeExFirst(0, mid, 0);
			} 
			else 
			{
				// 겹모음의 경우
				this.insertCompositeExFirst(VAL_INVALID, compositeMid, 0);
			}
		} 
		else if (comFirst != 0) 
		{
			// 자음+모음
			this.insertCompositeExFirst(VAL_INVALID, mid, 0);
		}
		else 
		{
			// 모음
			this.endComposite();	
			this.insertCompositeExFirst(0, mid, 0);
		}
	}
	
	int compositeFirstPart(int first1, int first2){
		for (int i = 0; i < 14; ++i) {
			if (compositeFirstTable[i][0] == first1 && compositeFirstTable[i][1] == first2) {
				return compositeFirstTable[i][2];
			}
		}
		return 0;				
	}
	
	int extractCompositeLast(int compositedLastCode, int idx)
	{
		if (compositedLastCode > 0 && compositedLastCode <= 27) {
			return extractLastTable[compositedLastCode-1][idx];
		}
		return 0;
	}
	
	/**
	 * 모음+모음=겹모음 얻기.
	 */
	int compositeMidPartFirst(int mid1, int mid2)
	{
		//현재는 12+14 건반만 지원.
		for (int i = 0; midCompositeTable[i][0] != -1; ++i) {	
			if (mid1 == midCompositeTable[i][0] && mid2 == midCompositeTable[i][1]) {
				return midCompositeTable[i][2];
			}
		}
		return 0;
	}
	
	/**
	 * A connection back to the service to communicate with the text field
	 * @param listener
	 */
	public void setComposing(StringBuilder aComposing) {
		mComposing = aComposing;
	}
	
	static public boolean isKoreanJamo(int first, int second )
	{
		boolean ret = false;
		if ( HangulManager.getJaumNoFromUniCode(first) >= 0 && HangulManager.getMoumNoFromUniCode(second) >= 0)
		{
			ret = true;
		}
		return ret;
		
	}
}
