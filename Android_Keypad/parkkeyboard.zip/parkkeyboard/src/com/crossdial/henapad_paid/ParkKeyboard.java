﻿/*
 *  Modified by z.c. on 2010/10 - 2012/03.
 *  Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 * 
 */

package com.crossdial.henapad_paid;

import java.util.ArrayList;
import java.util.List;

import android.content.res.Configuration;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.text.ClipboardManager;
import android.text.method.MetaKeyKeyListener;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;

import com.crossdial.henapad_paid.LatinKeyboard.LatinKey;
import com.google.android.voiceime.VoiceRecognitionTrigger;

/**
 * Example of writing an input method for a soft keyboard. This code is focused
 * on simplicity over completeness, so it should in no way be considered to be a
 * complete soft keyboard implementation. Its purpose is to provide a basic
 * example for how you would get started writing an input method, to be fleshed
 * out as appropriate.
 */
public class ParkKeyboard extends InputMethodService implements
		KeyboardView.OnKeyboardActionListener
{
	// 디버거 여부,

	// 음성 플레이
	private SoundManager			m_Sound;
	static final int				KEY_DOWN_SOUND			= 1;

	static final boolean			DEBUG					= false;					// true;
	public static final int			KEYBOARD_TYPE_KOREAN12	= 0;
	public static final int			KEYBOARD_TYPE_ENGLISH12	= 1;

	public static final int			KEYBOARD_TYPE_NUMBER20	= 3;
	public static final int			KEYBOARD_TYPE_SYMBOL20	= 4;
	public static final int			KEYBOARD_TYPE_CHINESE12	= 5;
	public static final int			KEYBOARD_TYPE_EDIT9		= 10;

	private boolean					m_shiftEffect			= false;

	HangulManager					hangulManager			= null;

	/**
	 * This boolean indicates the optional example code for performing
	 * processing of hard keys in addition to regular text generation from
	 * on-screen interaction. It would be used for input methods that perform
	 * language translations (such as converting text entered on a QWERTY
	 * keyboard to Chinese), but may not be used for input methods that are
	 * primarily intended to be used for on-screen text entry.
	 */
	static final boolean			PROCESS_HARD_KEYS		= true;

	public LatinKeyboardView		mInputView				= null;
	private CandidateView			mCandidateView			= null;
	private CompletionInfo[]		mCompletions			= null;

	private StringBuilder			mComposing				= new StringBuilder();
	private boolean					mPredictionOn;
	private boolean					mCompletionOn			= false;

	private boolean					mCapsLock;
	private long					mLastShiftTime;
	private long					mMetaState;

	private boolean					mLandscape				= false;

	private LatinKeyboard			mSymbolsKeyboard		= null;
	private LatinKeyboard			mNumbersKeyboard		= null;
	private LatinKeyboard			mEng12Keyboard			= null;
	private LatinKeyboard			mKor12Keyboard			= null;
	private LatinKeyboard			mEditKeyboard			= null;

	private int						mCurKeyboardType		= KEYBOARD_TYPE_ENGLISH12;
	private int						mLastKeyboardType;

	public int						m_shiftMode				= 0;

	private String					mWordSeparators;
	private ArrayList<String>		mCandiList				= new ArrayList<String>();

	private VoiceRecognitionTrigger	mVoiceRecognitionTrigger;

	// Handling of the custom multi-smiley key
	private long					mLastTapTime;
	private static final int		MULTITAP_INTERVAL		= 800;						// milliseconds

	/**
	 * Main initialization of the input method component. Be sure to call to
	 * super class.
	 */
	@Override
	public void onCreate()
	{
		// android.os.Debug.waitForDebugger();
		Logx.d("crossdial", "ParkKeyboard::onCreate");
		super.onCreate();

		

		mVoiceRecognitionTrigger = new VoiceRecognitionTrigger(this);
		mWordSeparators = getResources().getString(R.string.word_separators);
		initOnce();
	}

	pydic	m_pydic	= null;

	/**
	 * 키보드 서비스의 초기화 처리.
	 */
	void initOnce()
	{
		if (hangulManager != null)
			return;
		hangulManager = new HangulManager();
		hangulManager.delegate = this;
		hangulManager.setComposing(mComposing);

	}

	void createKeyboard(boolean landscape)
	{
		int eng_pad_id;
		eng_pad_id = R.xml.eng15keys_tab;
		eng_pad_id = R.xml.eng19keys_tab;
		// eng_pad_id = R.xml.eng15keys_tab_gray;
		if (landscape)
		{
			if (mLandscape == false || mEng12Keyboard == null)
			{
				mLandscape = true;
				// String VersionName =
				// getResources().getString(R.string.word_separators);
				mEng12Keyboard = new LatinKeyboard(this, eng_pad_id);
				mKor12Keyboard = new LatinKeyboard(this, R.xml.kor12keys);
				mSymbolsKeyboard = new LatinKeyboard(this, R.xml.sym20keys_land);
				// mNumbersKeyboard = new LatinKeyboard(this,
				// R.xml.num20keys_land);
				mNumbersKeyboard = new LatinKeyboard(this, R.xml.num16keys);
				mEditKeyboard = new LatinKeyboard(this, R.xml.edit9keys_tab);
			}
		}
		else
		{
			if (mLandscape == true || mEng12Keyboard == null)
			{
				mLandscape = false;
				mEng12Keyboard = new LatinKeyboard(this, eng_pad_id);
				mKor12Keyboard = new LatinKeyboard(this, R.xml.kor12keys);
				mSymbolsKeyboard = new LatinKeyboard(this, R.xml.sym20keys);
				// mNumbersKeyboard = new LatinKeyboard(this, R.xml.num20keys);
				mNumbersKeyboard = new LatinKeyboard(this, R.xml.num16keys);
				mEditKeyboard = new LatinKeyboard(this, R.xml.edit9keys_tab);
			}
		}

		if (mInputView != null)
		{
			mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
		}
	}

	private void refreshWidth()
	{
		int displayWidth = getMaxWidth();
		LatinKey.displayWidth = displayWidth;
		Display display = ((WindowManager) getSystemService(WINDOW_SERVICE))
				.getDefaultDisplay();
		DisplayMetrics outMetrics = new DisplayMetrics();
		display.getMetrics(outMetrics);
		int widthPixels = outMetrics.widthPixels;
		int heightPixels = outMetrics.heightPixels;

		int orientation = display.getOrientation();
		orientation = mOrientation; // somecase error.
		switch (orientation)
		{
			case Configuration.ORIENTATION_LANDSCAPE:
				break;
			case Configuration.ORIENTATION_PORTRAIT:
				break;
			default:
				break;
		}
		if (widthPixels > heightPixels)
			createKeyboard(true);
		else
			createKeyboard(false);

		int height = display.getHeight();
		int width = display.getWidth();
		Logx.d("crossdial",
				String.format(
						"refreshWidth(orientation = %d) widthPixels = %d, width = %d, height = %d, maxwidth = %d",
						orientation, widthPixels, width, height, displayWidth));

	}

	/**
	 * This is the point where you can do all of your UI initialization. It is
	 * called after creation and any configuration change.
	 */
	@Override
	public void onInitializeInterface()
	{

		// Configuration changes can happen after the keyboard gets recreated,
		// so we need to be able to re-build the keyboards if the available
		// space has changed.
		refreshWidth();
	}

	/**
	 * Called by the framework when your view for creating input needs to be
	 * generated. This will be called the first time your input method is
	 * displayed, and every time it needs to be re-created such as due to a
	 * configuration change.
	 */
	@Override
	public View onCreateInputView()
	{
		Logx.d("crossdial", "ParkKeyboard::onCreateInputView");
		handleClose();

		mInputView = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input, null);

		final View touchView = this.mInputView;
		touchView.setOnTouchListener(new View.OnTouchListener()
		{
			

			@Override
			public boolean onTouch(View v, MotionEvent event)
			{
				// TODO Auto-generated method stub
				
				System.out.println("Touch coordinates : "
						+ String.valueOf(event.getX()) + "x"
						+ String.valueOf(event.getY()));
				
				return false;
			}
		});
		
		
		mInputView.setService(this);
		mInputView.setOnKeyboardActionListener(this);

		mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));

		Logx.d("crossdial", "ParkKeyboard::onCreateInputView"); // Landscape
																// 방식에서 보여지지 않게
																// 한다.

		// 음성관련 2010.10.22
		m_Sound = new SoundManager(mInputView.getContext(), 1);
		m_Sound.load(KEY_DOWN_SOUND, R.raw.button);
		m_Sound.setVolume(8);

		if (m_pydic == null)
			m_pydic = new pydic(mInputView.getContext());

		return mInputView;
	}

	@Override
	public void onFinishInputView(boolean finishingInput)
	{
		mInputView.dismissPopupKeyboard();
	}

	private int	mOrientation;

	@Override
	public void onConfigurationChanged(Configuration newConfig)
	{
		super.onConfigurationChanged(newConfig);
		mOrientation = newConfig.orientation;
		Logx.d("crossdial", String.format(
				"ParkKeyboard::onConfigurationChanged orientation = %d",
				mOrientation));

		refreshWidth();

		switch (newConfig.orientation)
		{
			case Configuration.ORIENTATION_LANDSCAPE:
				break;

			case Configuration.ORIENTATION_PORTRAIT:
				break;
		}

	}

	/**
	 * Called by the framework when your view for showing candidates needs to be
	 * generated, like {@link #onCreateInputView}.
	 */
	@Override
	public View onCreateCandidatesView()
	{
		Logx.d("crossdial", "ParkKeyboard::onCreateCandidatesView");
		mCandidateView = new CandidateView(this);
		mCandidateView.setService(this);
		return mCandidateView;
	}

	/**
	 * This is the main point where we do our initialization of the input method
	 * to begin operating on an application. At this point we have been bound to
	 * the client, and are now receiving all of the detailed information about
	 * the target of our edits.
	 */
	@Override
	public void onStartInput(EditorInfo attribute, boolean restarting)
	{
		Logx.d("crossdial", "ParkKeyboard::onStartInput");
		super.onStartInput(attribute, restarting);
		// Reset our state. We want to do this even if restarting, because
		// the underlying state of the text editor could have changed in any
		// way.
		mComposing.setLength(0);
		updateCandidates();

		if (!restarting)
		{
			// Clear shift states.
			mMetaState = 0;
		}

		mPredictionOn = false;
		mCompletionOn = true;
		mCompletions = null;

		// We are now going to initialize our state based on the type of
		// text being edited.
		switch (attribute.inputType & EditorInfo.TYPE_MASK_CLASS)
		{
			case EditorInfo.TYPE_CLASS_NUMBER:
			case EditorInfo.TYPE_CLASS_DATETIME:
				// Numbers and dates default to the symbols keyboard, with
				// no extra features.
				mCurKeyboardType = KEYBOARD_TYPE_NUMBER20;
				break;

			case EditorInfo.TYPE_CLASS_PHONE:
				// Phones will also default to the symbols keyboard, though
				// often you will want to have a dedicated phone keyboard.
				mCurKeyboardType = KEYBOARD_TYPE_NUMBER20;
				break;

			case EditorInfo.TYPE_CLASS_TEXT:
				// This is general text editing. We will default to the
				// normal alphabetic keyboard, and assume that we should
				// be doing predictive text (showing candidates as the
				// user types).
				mCurKeyboardType = KEYBOARD_TYPE_ENGLISH12;
				if (mCurKeyboardType == KEYBOARD_TYPE_CHINESE12)
				{
					mPredictionOn = true;
				}
				// We now look for a few special variations of text that will
				// modify our behavior.
				int variation = attribute.inputType
						& EditorInfo.TYPE_MASK_VARIATION;
				if (variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD
						|| variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
				{
					// Do not display predictions / what the user is typing
					// when they are entering a password.
					mPredictionOn = false;
				}

				if (variation == EditorInfo.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
						|| variation == EditorInfo.TYPE_TEXT_VARIATION_URI
						|| variation == EditorInfo.TYPE_TEXT_VARIATION_FILTER)
				{
					// Our predictions are not useful for e-mail addresses
					// or URIs.
					mPredictionOn = false;
				}

				if ((attribute.inputType & EditorInfo.TYPE_TEXT_FLAG_AUTO_COMPLETE) != 0)
				{
					// If this is an auto-complete text view, then our predictions
					// will not be shown and instead we will allow the editor
					// to supply their own. We only show the editor's
					// candidates when in fullscreen mode, otherwise relying
					// own it displaying its own UI.
					mPredictionOn = false;
					mCompletionOn = isFullscreenMode();
					mCompletionOn = false;
				}

				// We also want to look at the current state of the editor
				// to decide whether our alphabetic keyboard should start out
				// shifted.
				updateCapsMode(attribute);
				break;

			default:
				// For all unknown input types, default to the alphabetic
				// keyboard with no special features.
				mCurKeyboardType = KEYBOARD_TYPE_ENGLISH12;
				updateCapsMode(attribute);
		}

		setCandidatesViewShown(false);

		// Update the label on the enter key, depending on what the application
		// says it will do.
		try
		{
			getKeyboardByType(mCurKeyboardType).setImeOptions(getResources(),
					attribute.imeOptions);
		}
		catch (Exception e)
		{
		}
	}

	/**
	 * This is called when the user is done editing a field. We can use this to
	 * reset our state.
	 */
	@Override
	public void onFinishInput()
	{
		Logx.d("crossdial", "ParkKeyboard::onFinishInput");
		super.onFinishInput();

		// Clear current composing text and candidates.
		handleClose();
		mComposing.setLength(0);
		updateCandidates();

		// We only hide the candidates window when finishing input on
		// a particular editor, to avoid popping the underlying application
		// up and down if the user is entering text into the bottom of
		// its window.
		setCandidatesViewShown(false);

		mCurKeyboardType = KEYBOARD_TYPE_ENGLISH12;

	}

	@Override
	public void onStartInputView(EditorInfo attribute, boolean restarting)
	{
		Logx.d("crossdial", "ParkKeyboard::onStartInputView");
		super.onStartInputView(attribute, restarting);
		if (mVoiceRecognitionTrigger != null)
		{
			mVoiceRecognitionTrigger.onStartInputView();
		}
		// Apply the selected keyboard to the input view.
		mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
		mInputView.closing();
	}

	/**
	 * Deal with the editor reporting movement of its cursor.
	 */
	@Override
	public void onUpdateSelection(int oldSelStart, int oldSelEnd,
			int newSelStart, int newSelEnd, int candidatesStart,
			int candidatesEnd)
	{
		Logx.d("crossdial", "ParkKeyboard::onUpdateSelection");
		super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
				candidatesStart, candidatesEnd);
		// Logx.i("onUpdateSelection() Composing.length=",
		// Integer.valueOf(mComposing.length()).toString());
		// If the current selection in the text view changes, we should
		// clear whatever candidate text we have.

		// 선택이 편집과 관련된것이 아닌가를 판단해야 한다.
		if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12 && candidatesEnd != -1
				&& newSelStart != candidatesEnd)
		{
			hangulManager.endComposite();
			hangulManager.clearComposite();
		}

		/*
		 * zc! if (mComposing.length() == 0 && (newSelStart != candidatesEnd ||
		 * newSelEnd != candidatesEnd)) { mComposing.setLength(0);
		 * updateCandidates(); hangulManager.endComposite(); InputConnection ic
		 * = getCurrentInputConnection(); if (ic != null) {
		 * ic.finishComposingText(); } }
		 */
	}

	LatinKeyboard getKeyboardByType(int keyboardType)
	{
		LatinKeyboard keyboard;
		switch (keyboardType)
		{
			case KEYBOARD_TYPE_ENGLISH12:
				keyboard = mEng12Keyboard;
				break;

			case KEYBOARD_TYPE_KOREAN12:
				keyboard = mKor12Keyboard;
				break;

			case KEYBOARD_TYPE_SYMBOL20:
				keyboard = mSymbolsKeyboard;
				break;

			case KEYBOARD_TYPE_EDIT9:
				keyboard = mEditKeyboard;
				break;

			case KEYBOARD_TYPE_NUMBER20:
				keyboard = mNumbersKeyboard;
				break;

			case KEYBOARD_TYPE_CHINESE12:
				keyboard = mEng12Keyboard;
				break;

			default:
				keyboard = mEng12Keyboard;
		}
		return keyboard;
	}

	/**
	 * This tells us about completions that the editor has determined based on
	 * the current text in it. We want to use this in fullscreen mode to show
	 * the completions ourself, since the editor can not be seen in that
	 * situation.
	 */
	@Override
	public void onDisplayCompletions(CompletionInfo[] completions)
	{
		Logx.d("crossdial", "ParkKeyboard::onDisplayCompletions");
		if (true)
			return;

		if (mCompletionOn)
		{
			mCompletions = completions;
			if (completions == null)
			{
				setSuggestions(null, false, false);
				return;
			}

			List<String> stringList = new ArrayList<String>();
			for (int i = 0; i < (completions != null ? completions.length : 0); i++)
			{
				CompletionInfo ci = completions[i];
				if (ci != null)
					stringList.add(ci.getText().toString());
			}
			setSuggestions(stringList, true, true);
		}
	}

	/**
	 * This translates incoming hard key events in to edit operations on an
	 * InputConnection. It is only needed when using the PROCESS_HARD_KEYS
	 * option.
	 */
	private boolean translateKeyDown(int keyCode, KeyEvent event)
	{
		/**
		 * 현재 지원하지 않는다. mMetaState =
		 * MetaKeyKeyListener.handleKeyDown(mMetaState, keyCode, event); int c =
		 * event.getUnicodeChar(MetaKeyKeyListener.getMetaState(mMetaState));
		 * mMetaState = MetaKeyKeyListener.adjustMetaAfterKeypress(mMetaState);
		 * InputConnection ic = getCurrentInputConnection(); if (c == 0 || ic ==
		 * null) { return false; }
		 * 
		 * boolean dead = false;
		 * 
		 * if ((c & KeyCharacterMap.COMBINING_ACCENT) != 0) { dead = true; c = c
		 * & KeyCharacterMap.COMBINING_ACCENT_MASK; }
		 * 
		 * if (mComposing.length() > 0) { char accent =
		 * mComposing.charAt(mComposing.length() -1 ); int composed =
		 * KeyEvent.getDeadChar(accent, c);
		 * 
		 * if (composed != 0) { c = composed;
		 * mComposing.setLength(mComposing.length()-1); } }
		 * 
		 * onKey(c, null);
		 */
		return true;
	}

	/**
	 * Use this to monitor key events being delivered to the application. We get
	 * first crack at them, and can either resume them or let them continue to
	 * the app.
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		Logx.d("crossdial", "ParkKeyboard::onKeyDown");
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				// The InputMethodService already takes care of the back
				// key for us, to dismiss the input method if it is shown.
				// However, our keyboard could be showing a pop-up window
				// that back should dismiss, so we first allow it to do that.
				if (event.getRepeatCount() == 0 && mInputView != null)
				{
					if (mInputView.handleBack())
					{
						return true;
					}
				}
				break;

			case KeyEvent.KEYCODE_DEL:
				// Special handling of the delete key: if we currently are
				// composing text for the user, we want to modify that instead
				// of let the application to the delete itself.
				if (mComposing.length() > 0)
				{
					onKey(Keyboard.KEYCODE_DELETE, null);
					return true;
				}
				break;

			case KeyEvent.KEYCODE_ENTER:
				// Let the underlying text editor always handle these.
				return false;

			default:
				System.out.println("called...");
				// For all other keys, if we want to do transformations on
				// text being entered with a hard keyboard, we need to process
				// it and do the appropriate action.
				if (PROCESS_HARD_KEYS)
				{
					if (keyCode == KeyEvent.KEYCODE_SPACE
							&& (event.getMetaState() & KeyEvent.META_ALT_ON) != 0)
					{
						// A silly example: in our input method, Alt+Space
						// is a shortcut for 'android' in lower case.
						InputConnection ic = getCurrentInputConnection();
						if (ic != null)
						{
							// First, tell the editor that it is no longer in the
							// shift state, since we are consuming this.
							ic.clearMetaKeyStates(KeyEvent.META_ALT_ON);
							keyDownUp(KeyEvent.KEYCODE_A);
							keyDownUp(KeyEvent.KEYCODE_N);
							keyDownUp(KeyEvent.KEYCODE_D);
							keyDownUp(KeyEvent.KEYCODE_R);
							keyDownUp(KeyEvent.KEYCODE_O);
							keyDownUp(KeyEvent.KEYCODE_I);
							keyDownUp(KeyEvent.KEYCODE_D);
							// And we consume this event.
							return true;
						}
					}
					if (mPredictionOn && translateKeyDown(keyCode, event))
					{
						return true;
					}
				}
		}

		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Use this to monitor key events being delivered to the application. We get
	 * first crack at them, and can either resume them or let them continue to
	 * the app.
	 */
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		Logx.d("crossdial", "ParkKeyboard::onKeyUp");
		// If we want to do transformations on text being entered with a hard
		// keyboard, we need to process the up events to update the meta key
		// state we are tracking.
		if (PROCESS_HARD_KEYS)
		{
			if (mPredictionOn)
			{
				mMetaState = MetaKeyKeyListener.handleKeyUp(mMetaState,
						keyCode, event);
			}
		}
		// Logx.i("onKeyUp() Composing.length=",
		// Integer.valueOf(mComposing.length()).toString());
		return super.onKeyUp(keyCode, event);
	}

	/**
	 * Helper function to commit any text being composed in to the editor.
	 */
	private void commitTyped(InputConnection inputConnection, int index)
	{
		if (mCandiList != null && index >= 0 && index < mCandiList.size())
		{
			inputConnection.commitText(mCandiList.get(index), 1);
			mComposing.setLength(0);
			updateCandidates();
			hangulManager.endComposite();
		}
		else
		{
			if (mComposing.length() > 0)
			{
				inputConnection.commitText(mComposing, 1);
				mComposing.setLength(0);
				updateCandidates();
				hangulManager.endComposite();
			}
		}
	}

	/**
	 * Helper to update the shift state of our keyboard based on the initial
	 * editor state.
	 */
	private void updateCapsMode(EditorInfo ei)
	{
		if (mInputView == null)
			return;
		if (mEng12Keyboard == mInputView.getKeyboard())
		{
			int caps = 0;
			if (ei == null)
			{
				ei = getCurrentInputEditorInfo();
			}

			if (ei != null && ei.inputType != EditorInfo.TYPE_NULL)
			{
				caps = getCurrentInputConnection().getCursorCapsMode(
						ei.inputType);
			}

			if (caps != 0)
			{
				setShiftEffect(true);
			}
		}

		boolean curShift = mInputView.isShifted();
		boolean newShift = m_shiftEffect || mCapsLock;
		newShift = m_shiftMode > 0; // shift
		if (curShift != newShift)
		{
			mInputView.setShifted(newShift);
			LatinKeyboard kb = (LatinKeyboard) mInputView.getKeyboard();
			kb._setShifted(newShift);
		}
		mInputView.invalidate();
	}

	/**
	 * Helper to determine if a given character code is alphabetic.
	 */
	private boolean isAlphabet(int code)
	{
		if (Character.isLetter(code))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Helper to send a key down / key up pair to the current editor.
	 */
	private void keyDownUp(int keyEventCode)
	{
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode));
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_UP, keyEventCode));
	}

	/**
	 * Helper to send a character to the editor as raw key events.
	 */
	private void sendKey1(int keyCode)
	{
		switch (keyCode)
		{
			case '\n':
				keyDownUp(KeyEvent.KEYCODE_ENTER);
				break;
			default:
				System.out.println("called send key");
				if (keyCode >= '0' && keyCode <= '9')
				{
					keyDownUp(keyCode - '0' + KeyEvent.KEYCODE_0);
				}
				else if (keyCode == 32)
				{
					// Logx.i("commitText()", "<-sendKey");

					if (getCurrentInputConnection() != null)
						getCurrentInputConnection().commitText(
								String.valueOf((char) keyCode), 1);
				}
				else if (keyCode == 33)
				{
					System.out.println("testing " + keyCode);

				}
				break;
		}
	}

	/************************************************************
	 * 
	 * Implementation of KeyboardViewListener
	 * 
	 ************************************************************/

	public boolean checkEditKey(int primaryCode)
	{
		boolean processed = false;
		CharSequence buf, sel;
		ClipboardManager clipboard = null;
		ExtractedTextRequest req;
		ExtractedText txt;
		int st, en;

		switch (primaryCode)
		{
			case KeyEvent.KEYCODE_DPAD_UP:
			case KeyEvent.KEYCODE_DPAD_DOWN:
			case KeyEvent.KEYCODE_DPAD_LEFT:
			case KeyEvent.KEYCODE_DPAD_RIGHT:
				// composite �??�성?�야 ?�다.
				keyDownUp(primaryCode);
				processed = true;
				break;

			case KeyEvent.KEYCODE_DEL:
				req = new ExtractedTextRequest();
				txt = getCurrentInputConnection().getExtractedText(req, 0);
				if (txt != null)
				{
					st = txt.selectionStart;
					en = txt.selectionEnd;
					if (txt.selectionStart != txt.selectionEnd)
					{
						keyDownUp(KeyEvent.KEYCODE_DEL);
					}
					else
					{
						if (st < txt.text.length())
						{
							getCurrentInputConnection().deleteSurroundingText(
									0, 1);
						}
					}
				}
				else
				{
					keyDownUp(KeyEvent.KEYCODE_DEL);
				}
				processed = true;
				break;

			case -10: // copy
				clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				req = new ExtractedTextRequest();
				txt = getCurrentInputConnection().getExtractedText(req, 0);
				if (txt != null && txt.selectionStart != txt.selectionEnd)
				{
					st = txt.selectionStart;
					en = txt.selectionEnd;
					if (txt.selectionStart > txt.selectionEnd)
					{
						st = txt.selectionEnd;
						en = txt.selectionStart;
					}
					sel = txt.text.subSequence(st, en);

					clipboard.setText(sel);
				}
				processed = true;
				break;

			case -12: // paste
				clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				buf = clipboard.getText();
				getCurrentInputConnection().commitText(buf, 1);

				processed = true;
				break;

			case -16: // cut
				clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				req = new ExtractedTextRequest();
				txt = getCurrentInputConnection().getExtractedText(req, 0);
				if (txt != null && txt.selectionStart != txt.selectionEnd)
				{
					st = txt.selectionStart;
					en = txt.selectionEnd;
					if (txt.selectionStart > txt.selectionEnd)
					{
						st = txt.selectionEnd;
						en = txt.selectionStart;
					}
					sel = txt.text.subSequence(st, en);

					clipboard.setText(sel);
					keyDownUp(KeyEvent.KEYCODE_DEL);
				}
				processed = true;
				break;

			case -14: // 블럭
				LatinKeyboard current = (LatinKeyboard) mInputView
						.getKeyboard();
				current.setBlock(!current.getBlock());

				if (current.getBlock())
				{
					getCurrentInputConnection().sendKeyEvent(
							new KeyEvent(KeyEvent.ACTION_DOWN,
									KeyEvent.KEYCODE_SHIFT_LEFT));
				}
				else
				{
					getCurrentInputConnection().sendKeyEvent(
							new KeyEvent(KeyEvent.ACTION_UP,
									KeyEvent.KEYCODE_SHIFT_LEFT));
				}
				processed = true;
				mInputView.invalidateAllKeys();
				break;
		}

		return processed;

	}

	void handleModeChange()
	{
		if (mCurKeyboardType == KEYBOARD_TYPE_ENGLISH12)
		{
			mCurKeyboardType = KEYBOARD_TYPE_KOREAN12;
			mCurKeyboardType = KEYBOARD_TYPE_CHINESE12;
		}
		else if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12)
		{
			mCurKeyboardType = KEYBOARD_TYPE_ENGLISH12;
			mCurKeyboardType = KEYBOARD_TYPE_CHINESE12;
		}
		else if (mCurKeyboardType == KEYBOARD_TYPE_CHINESE12)
		{
			mCurKeyboardType = KEYBOARD_TYPE_ENGLISH12;
		}
		else
		{
			mCurKeyboardType = mLastKeyboardType;
		}

		if (mCurKeyboardType == KEYBOARD_TYPE_CHINESE12)
		{
			setCandidatesViewShown(true);
		}
		else
		{
			setCandidatesViewShown(false);
		}
		mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
	}

	private boolean isLanguageboard(int boardType)
	{
		switch (boardType)
		{
			case KEYBOARD_TYPE_ENGLISH12:
			case KEYBOARD_TYPE_KOREAN12:
			case KEYBOARD_TYPE_CHINESE12:
				return true;
		}
		return false;

	}

	public void onKey(int primaryCode, int[] keyCodes)
	{

		Logx.d("crossdial", ">>> OnKey");
		if (mInputView == null)
		{
			return;
		}

		if (getCurrentInputConnection() == null) // 2012.3.14 zc
			return;

		// Test Edit board key.
		boolean processed = checkEditKey(primaryCode);

		System.out.println("method callled");
		switch (primaryCode)
		{
			case Keyboard.KEYCODE_DELETE:
				System.out.println("called...1");
				handleBackspace();
				break;
			case Keyboard.KEYCODE_SHIFT:
				System.out.println("called...2");
				handleShift();
				break;
			case Keyboard.KEYCODE_CANCEL:
				System.out.println("called...3");
				handleClose();
				return;
			case LatinKeyboardView.KEYCODE_OPTIONS:
				System.out.println("called...4");
				break;
			case Keyboard.KEYCODE_MODE_CHANGE:
				System.out.println("called...5");
				handleModeChange();
				break;
			case -117:// to Number board
				System.out.println("called...6");
				if (isLanguageboard(mCurKeyboardType))
				{
					mLastKeyboardType = mCurKeyboardType;
				}
				mCurKeyboardType = KEYBOARD_TYPE_NUMBER20;
				mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
				setCandidatesViewShown(false);

				break;
			case -119: // to Edit board //zc 2010.10.21
				System.out.println("called...7");
				if (isLanguageboard(mCurKeyboardType))
				{
					mLastKeyboardType = mCurKeyboardType;
				}
				mCurKeyboardType = KEYBOARD_TYPE_EDIT9;
				mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
				setCandidatesViewShown(false);
				break;

			case -121: // Microphone
				System.out.println("called microphone");
				mVoiceRecognitionTrigger.startVoiceRecognition();
				break;

			case -101: // to Sign board.
				System.out.println("called...8");
				if (isLanguageboard(mCurKeyboardType))
				{
					mLastKeyboardType = mCurKeyboardType;
				}
				mCurKeyboardType = KEYBOARD_TYPE_SYMBOL20;
				mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
				setCandidatesViewShown(false);
				break;

			case -102: // to Language board.
				System.out.println("called...9");
				if (!isLanguageboard(mCurKeyboardType))
				{
					mCurKeyboardType = mLastKeyboardType;
					if (mCurKeyboardType == KEYBOARD_TYPE_CHINESE12)
						setCandidatesViewShown(true);
					else
						setCandidatesViewShown(false);
				}
				mInputView.setKeyboard(getKeyboardByType(mCurKeyboardType));
				break;
			case -250: // First part of the {^^,:),XD} set ^^
			case -251: // Second part of the {^^,:),XD} set :)
			case -252: // Third part of the {^^,:),XD} set XD
				System.out.println("called...10");
				InputConnection cic = getCurrentInputConnection();
				ExtractedText text = cic.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime = System.currentTimeMillis();
				if (currentTime - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic.deleteSurroundingText(1, 0);
				}
				text = cic.getExtractedText(new ExtractedTextRequest(), 0);
				if (primaryCode == -250)
				{
					cic.commitText("^^", text.text.length() + 2);
				}
				else if (primaryCode == -251)
				{
					cic.commitText(":)", text.text.length() + 2);
				}
				else if (primaryCode == -252)
				{
					cic.commitText("XD", text.text.length() + 2);
				}
				mLastTapTime = currentTime;
				break;
			case 77:
			{
				//.com
				InputConnection cic_77 = getCurrentInputConnection();
				ExtractedText text_77 = cic_77.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_77 = System.currentTimeMillis();
				if (currentTime_77 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_77.deleteSurroundingText(1, 0);
				}
				text_77 = cic_77
						.getExtractedText(new ExtractedTextRequest(), 0);
				cic_77.commitText(".com", text_77.text.length() + 2);
				break;
			}
			case 64:
			{
				//.com
				InputConnection cic_64 = getCurrentInputConnection();
				ExtractedText text_64 = cic_64.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_64 = System.currentTimeMillis();
				if (currentTime_64 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_64.deleteSurroundingText(1, 0);
				}
				text_64 = cic_64
						.getExtractedText(new ExtractedTextRequest(), 0);
				cic_64.commitText("@", text_64.text.length() + 2);
				break;
			}
			case 63:
			{
				//.com
				InputConnection cic_63 = getCurrentInputConnection();
				ExtractedText text_63 = cic_63.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_63 = System.currentTimeMillis();
				if (currentTime_63 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_63.deleteSurroundingText(1, 0);
				}
				text_63 = cic_63
						.getExtractedText(new ExtractedTextRequest(), 0);
				cic_63.commitText("?", text_63.text.length() + 2);
				break;
			}
			case 158:
			{
				//.com
				InputConnection cic_158 = getCurrentInputConnection();
				ExtractedText text_158 = cic_158.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_63 = System.currentTimeMillis();
				if (currentTime_63 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_158.deleteSurroundingText(1, 0);
				}
				text_158 = cic_158.getExtractedText(new ExtractedTextRequest(),
						0);
				cic_158.commitText(".", text_158.text.length() + 2);
				break;
			}
			case 55:
			{
				//.com
				InputConnection cic_55 = getCurrentInputConnection();
				ExtractedText text_55 = cic_55.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_55 = System.currentTimeMillis();
				if (currentTime_55 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_55.deleteSurroundingText(1, 0);
				}
				text_55 = cic_55
						.getExtractedText(new ExtractedTextRequest(), 0);
				cic_55.commitText(",", text_55.text.length() + 2);
				break;
			}
			case 75:
			{
				//.com
				InputConnection cic_75 = getCurrentInputConnection();
				ExtractedText text_75 = cic_75.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_75 = System.currentTimeMillis();
				if (currentTime_75 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_75.deleteSurroundingText(1, 0);
				}
				text_75 = cic_75
						.getExtractedText(new ExtractedTextRequest(), 0);
				cic_75.commitText("'", text_75.text.length() + 2);
				break;
			}
			case 154:
			{
				//.com
				InputConnection cic_154 = getCurrentInputConnection();
				ExtractedText text_154 = cic_154.getExtractedText(
						new ExtractedTextRequest(), 0);
				long currentTime_154 = System.currentTimeMillis();
				if (currentTime_154 - mLastTapTime < MULTITAP_INTERVAL)
				{
					// Timer is running, delete the old smile we inputed
					// We only delete 1 character because Android will delete 1 by
					// default
					cic_154.deleteSurroundingText(1, 0);
				}
				text_154 = cic_154.getExtractedText(new ExtractedTextRequest(),
						0);
				cic_154.commitText("/", text_154.text.length() + 2);
				break;
			}

			default:
				System.out.println("called...default");

				System.out.println("primaryCode" + primaryCode);
				if (isWordSeparator(primaryCode))
				{
					// Handle separator
					System.out.println("called...default1");
					if (mComposing.length() > 0)
					{
						System.out.println("called...default2");
						commitTyped(getCurrentInputConnection(), -1);
					}
					// System.out.println("mComposing.length()"
					// +mComposing.length());
					sendKey1(primaryCode);
				}
				else if (processed == false)
				{
					System.out.println("called...default3");
					Logx.d("crossdial", " OnKey 2");
					handleCharacter(primaryCode);
				}
				break;

		}

		updateCapsMode(null); // zc

		Logx.d("crossdial", "<<< OnKey");
	}

	public void onText(CharSequence text)
	{
		setShiftEffect(false);
		InputConnection ic = getCurrentInputConnection();
		if (ic == null)
			return;
		ic.beginBatchEdit();

		if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12)
		{
			for (int i = 0; i < text.length(); i++)
			{
				hangulManager.IMEModeKorean(text.charAt(i));
			}
			ic.setComposingText(mComposing, 1);
			if (text.length() > 1)
				commitTyped(ic, -1);
		}
		else if (text.length() == 1)
		{
			hangulManager.clearComposite();
			handleCharacter(text.charAt(0));
		}
		else
		{
			hangulManager.clearComposite();
			commitTyped(ic, -1);
			ic.commitText(text, 0);
		}
		ic.endBatchEdit();
		updateCapsMode(null);
	}

	/**
	 * Update the list of available candidates from the current composing text.
	 * This will need to be filled in by however you are determining candidates.
	 */
	private void updateCandidates()
	{
		boolean bUsing = true;
		if (!mCompletionOn)
			bUsing = false;

		if (mCurKeyboardType != KEYBOARD_TYPE_CHINESE12)
		{
			bUsing = false;
			// if(mCandidateView != null)
			// mCandidateView.setVisibility(4);//INVISIBLE
		}
		else
		{
			// if(mCandidateView != null)
			// mCandidateView.setVisibility(0);//VISIBLE
		}

		if (mComposing.length() == 0)
		{
			bUsing = false;
		}

		if (bUsing == false)
		{
			setSuggestions(null, false, false);
			oldComposing = "";
			return;
		}

		if (oldComposing.compareToIgnoreCase(mComposing.toString()) == 0)
			return;// Not need to update.

		oldComposing = mComposing.toString();
		mCandiList.clear();
		mCandiList.add(mComposing.toString());
		ArrayList<String> candi_list = new ArrayList<String>();
		m_pydic.GetCandidates(mComposing.toString(), candi_list);
		if (candi_list.size() > 0)
		{
			String candi = candi_list.get(0);
			for (int i = 0; i < candi.length(); i++)
			{
				mCandiList.add(candi.substring(i, i + 1));
				if (mCandiList.size() == CandidateView.MAX_SUGGESTIONS - 1)
				{
					break;
				}
			}
			mCandiList.add(mComposing.toString());
		}

		setSuggestions(mCandiList, true, true);
	}

	String	oldComposing	= "";

	public void setSuggestions(List<String> suggestions, boolean completions,
			boolean typedWordValid)
	{
		if (suggestions != null && suggestions.size() > 0)
		{
			setCandidatesViewShown(true);
		}
		else if (isExtractViewShown())
		{
			setCandidatesViewShown(true);
		}
		if (mCandidateView != null)
		{
			mCandidateView.setSuggestions(suggestions, completions,
					typedWordValid);
		}
	}

	public void handleBackspace()
	{
		int length = mComposing.length();

		if (length >= 1)
		{
			if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12)
			{
				hangulManager.doErase();
				getCurrentInputConnection().setComposingText(mComposing, 1);
			}
			else if (length > 1)
			{
				mComposing.delete(length - 1, length);
				getCurrentInputConnection().setComposingText(mComposing, 1);
			}
			else
			{
				mComposing.setLength(0);
				getCurrentInputConnection().commitText("", 0);
			}

			updateCandidates();
		}
		else
		{
			if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12)// &&
															// mComposing.length()
															// > 0)
			{
				hangulManager.doErase();
				getCurrentInputConnection().setComposingText(mComposing, 1);
			}
			else
			{
				keyDownUp(KeyEvent.KEYCODE_DEL);
			}
		}

		updateCapsMode(null);
	}

	private void setShiftEffect(boolean val)
	{
		m_shiftEffect = val;
		if (m_shiftMode == 0 && m_shiftEffect == true)
		{
			m_shiftMode = 1;
		}
		if (m_shiftMode == 1 && m_shiftEffect == false)
		{
			m_shiftMode = 0;
		}

	}

	private void handleShift()
	{
		if (DEBUG)
		{
			ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
			clipboard.setText(Logx.logs.substring(0));
			Logx.logs.setLength(0);
		}

		if (mInputView == null)
		{
			return;
		}
		m_shiftEffect = !m_shiftEffect;
		m_shiftMode = (m_shiftMode + 1) % 3;
		if (m_shiftMode == 0)
		{
			m_shiftEffect = false;
		}
		checkToggleCapsLock();

		updateCapsMode(null);

	}

	private void handleCharacter(int primaryCode)
	{
		Logx.d("crossdial", " >>> handleCharacter");

		setShiftEffect(false);
		if (mCurKeyboardType == KEYBOARD_TYPE_KOREAN12)
		{
			hangulManager.IMEModeKorean(primaryCode);
			getCurrentInputConnection().setComposingText(mComposing, 1);
			// updateCapsMode(null);
			updateCandidates();
		}
		else if (mCurKeyboardType == KEYBOARD_TYPE_CHINESE12)
		{
			mComposing.append(String.format("%c", primaryCode));
			getCurrentInputConnection().setComposingText(mComposing, 1);
			updateCandidates();
		}
		else
		{

			if (isInputViewShown())
			{
				if (mInputView.isShifted())
				{
					primaryCode = Character.toUpperCase(primaryCode);
				}
				else
				{
					primaryCode = Character.toLowerCase(primaryCode);
				}
			}

			Logx.d("crossdial", " handleCharacter 1");
			if (isAlphabet(primaryCode) && mPredictionOn)
			{
				Logx.d("crossdial", " handleCharacter 2");
				// Logx.i("handleCharacter()",
				// Integer.valueOf(primaryCode).toString());
				mComposing.append((char) primaryCode);
				Logx.d("crossdial", " handleCharacter 3");
				// Logx.i("handleCharacter()",
				// Integer.valueOf(mComposing.length()).toString());
				getCurrentInputConnection().setComposingText(mComposing, 1);
				Logx.d("crossdial", " handleCharacter 4");
				// updateCapsMode(null);
				Logx.d("crossdial", " handleCharacter 5");
				// updateCandidates();
				Logx.d("crossdial", " handleCharacter 6");
			}
			else
			{
				commitTyped(getCurrentInputConnection(), -1);
				// Logx.i("commitText()", "<-handleCharacter");
				Logx.d("crossdial", " >>> handleCharacter 7");
				getCurrentInputConnection().commitText(
						String.valueOf((char) primaryCode), 1); // ??
				Logx.d("crossdial", " >>> handleCharacter 8");
			}
			updateCandidates();// 2012.3.7
		}
	}

	private void handleClose()
	{
		commitTyped(getCurrentInputConnection(), -1);
		if (mInputView != null)
		{
			mInputView.dismissPopupKeyboard();
			mInputView.closing();
		}
		requestHideSelf(0);
	}

	private void checkToggleCapsLock()
	{
		long now = System.currentTimeMillis();
		// if(m_shiftMode == 2)
		{
			LatinKeyboard kb = (LatinKeyboard) mInputView.getKeyboard();
			kb.setCapsLock(m_shiftMode == 2);
			mInputView.invalidateAllKeys();
		}

		if (mLastShiftTime + 800 > now)
		{
			mCapsLock = !mCapsLock;
			// shift 설정을 막음,
			mLastShiftTime = 0;
		}
		else
		{
			mLastShiftTime = now;
		}
	}

	private String getWordSeparators()
	{
		return mWordSeparators;
	}

	public boolean isWordSeparator(int code)
	{
		String separators = getWordSeparators();
		System.out.println("seperator" + separators);
		return separators.contains(String.valueOf((char) code));
	}

	public void pickDefaultCandidate()
	{
		pickSuggestionManually(0);
	}

	public void pickSuggestionManually(int index)
	{
		if (mCompletionOn && mCompletions != null && index >= 0
				&& index < mCompletions.length)
		{
			CompletionInfo ci = mCompletions[index];
			getCurrentInputConnection().commitCompletion(ci);
			if (mCandidateView != null)
			{
				mCandidateView.clear();
			}
			updateCapsMode(getCurrentInputEditorInfo());
		}
		else if (mComposing.length() > 0)
		{
			// If we were generating candidate suggestions for the current
			// text, we would commit one of them here. But for this sample,
			// we will just commit the current text.
			commitTyped(getCurrentInputConnection(), index);
		}
	}

	public void swipeRight()
	{
		if (mCompletionOn)
		{
			pickDefaultCandidate();
		}
	}

	public void swipeLeft()
	{
		handleBackspace();
	}

	public void swipeDown()
	{
		handleClose();
	}

	public void swipeUp()
	{
	}

	public void onPress(int primaryCode)
	{
		m_Sound.play(KEY_DOWN_SOUND);
		if (primaryCode == -1)
		{
			Logx.d("crossdial", "### onPress:: shift");
		}
		else
		{
			String str;
			if (primaryCode > 0)
				str = String.format("### onPress:: code = %d (%c)",
						primaryCode, primaryCode);
			else
				str = String.format("### onPress:: code = %d (?)", primaryCode);

			Logx.d("crossdial", str);
			if (primaryCode >= 0x20)
			{
				// m_Sound.play(KEY_DOWN_SOUND);
			}
		}
	}

	public void onRelease(int primaryCode)
	{
		if (primaryCode == -1)
		{
			Logx.d("crossdial", "### onRelease:: shift");
		}
		else
		{
			String str;
			if (primaryCode > 0)
				str = String.format("### onRelease:: code = %d (%c)",
						primaryCode, primaryCode);
			else
				str = String.format("### onRelease:: code = %d (?)",
						primaryCode);
			Logx.d("crossdial", str);
		}
	}

	public int getCurrentKeyboardType()
	{
		return mCurKeyboardType;
	}

	/**
	 * z' code 2010.10.26
	 * 
	 * @return
	 */
	public int getCurrentBackChar(int backCount)
	{
		ExtractedTextRequest req;
		ExtractedText txt;
		int st;

		req = new ExtractedTextRequest();
		txt = getCurrentInputConnection().getExtractedText(req, 0);
		if (txt != null && txt.selectionStart == txt.selectionEnd)
		{
			st = txt.selectionStart;
			if (backCount < 0)
				backCount = 0;
			st -= backCount;
			if (st < 0)
				st = 0;

			return txt.text.charAt(st);
		}
		return 0;
	}

	public void endComposing()
	{
		if (mComposing.length() > 0)
		{
			getCurrentInputConnection().setComposingText(mComposing, 1);
			getCurrentInputConnection().finishComposingText();
			mComposing.setLength(0);
		}

		return;
	}

	public void insertText(String ch)
	{
		mComposing.append(ch);
		return;
	}

	public void backAndInsert(String ch)
	{
		if (mComposing.length() > 0)
		{
			mComposing.deleteCharAt(mComposing.length() - 1);
		}
		else
		{
			getCurrentInputConnection().deleteSurroundingText(1, 0);
		}

		if (ch != null && ch.length() > 0)
		{
			mComposing.append(ch);
		}

		return;
	}
}
