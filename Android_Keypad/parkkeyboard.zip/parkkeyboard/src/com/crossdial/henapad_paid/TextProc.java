﻿/*
 *  Modified by z.c. on 2010/10 - 2012/03.
 *  Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 * 
 */

package com.crossdial.henapad_paid;

import java.io.InputStream;
import java.util.ArrayList;

import android.R.id;
import android.content.res.Resources;

public class TextProc 
{
	static public boolean isKoreanJamo(int first, int second )
	{
		boolean ret = false;
		if ( HangulManager.getJaumNoFromUniCode(first) >= 0 && HangulManager.getMoumNoFromUniCode(second) >= 0)
		{
			ret = true;
		}
		return ret;
		
	}
	static public String xLoad_File2String( Resources res, int fileId )
	{
		byte[] buf = xLoad_File( res, fileId );
		if(buf == null)
		{
			return "";
		}
		String ret = "";
		try {
			ret = new String(buf, 0, buf.length, "UTF-8");
		} catch (Exception e) {
		}
		return ret;
	}

	/**
	 * 리소스의 텍스트를 읽어들이기.
	 * @param res
	 * @param filename
	 * @return
	 */
	static public byte[] xLoad_File( Resources res, int fileId )
	{	
		byte buffer[] = null;
		
		int fsz     = 0;
		boolean ok = false;
		long now = System.currentTimeMillis();
		while(ok==false){
			try
			{
				
				InputStream pF 	= null;	
				pF = res.openRawResource(fileId);				
				fsz = pF.available();	
				
				buffer =new byte[fsz ];		
				pF.read(buffer );
				pF.close();
				pF = null;
				ok = true;
			}
			catch( Exception e){
				ok = false; 
				String str = String.format("Fail!!! xLoad_File file:%X", fileId);
				Logx.d("crossdial", str);
				if (System.currentTimeMillis() > now + 800)
				{
					ok = true;
					Logx.d("crossdial", "Fail!!! xLoad_File!!!" );
				}
			}
		}
		return buffer;
	}
	
	/**
	 * 행단위로 해석하여 단어 리스트를 작성한다.
	 * @return
	 */
    static public int getWordArray(String text,  ArrayList<String> first, ArrayList<String> second)
    {
    	if(first == null) return 0;
        String cur;
        text = text.replace('\r', '\n');
        text = text.replaceAll("\n\n", "\n");
        
        String[] arr = text.split("\n");
        String[] word; 
    	for(int i = 0; i < arr.length; i++ )
    	{
    		cur = arr[i];
    		if(cur.length() == 0)
    			continue;
    		word = cur.split(":");
    		if(word.length == 1)
    		{
    			first.add(word[0]);
    			if(second != null)
    				second.add(word[0]);
    		}
    		else
    		{
    			first.add(word[0]);
    			if(second != null)
    				second.add(word[1]);
    		}
    	}   	
    	return first.size();
    }
    
    /**
     * 문자열에서 단어의 포함관계를  검사한다. 
     * @param string 	"abcdef"
     * @param word		"acdf"
     * @return
     */
	public static boolean isContainString(String string, String word, boolean bFisrtEqual)
	{
//		NSLog(@" #### Findig, string=%@, word=%@", string, word);
		int ch, chWord;
		int len, lenWord;

		len = string.length();
		lenWord = word.length();

		if( lenWord == 0 || len < lenWord )
		{
//			NSLog(@" #### Not Found, len < lenWord");
			return false;
		}

		ch = string.charAt(0);
		chWord = word.charAt(0);
		if( bFisrtEqual )
		{
			if( ch != chWord )
			{
//	 			NSLog(@" #### Not Found, !bFisrtEqual");
				return false;
			}
		}

		int i, posWord = 0;

		for(i = 0; i < len; i++)
		{
			ch = string.charAt(i);
			if(ch == chWord)
			{
				posWord++;
//	 			NSLog(@" #### Finding, posWord = %d", posWord);
				if(posWord == lenWord)
				{
//	 				NSLog(@" #### Found");
					return true;
				}
				chWord = word.charAt(posWord);
			}
		}

//	 	NSLog(@" #### Not Found >>>");
		return false;
	}

	public static int findCandidate(String string, ArrayList<String> wordList)
	{
		if(wordList == null) return -1;
		if(string == null) return -1;
		ArrayList<Integer> candidatesWithoutTail = new ArrayList<Integer>();
		ArrayList<Integer> candidatesWithTail = new ArrayList<Integer>();
		int i, count;
		count = wordList.size();
		String word;
		char finalChar = string.charAt(string.length() - 1);
		for(i = 0; i < count; i++)
		{
			word = wordList.get(i);
			// NSLog(@"word %d, <%@>", word.length, word);
			if( isContainString(string, word, true) )
			{
				if (word.charAt(word.length() - 1) == finalChar) {
					candidatesWithTail.add(Integer.valueOf(i));
				} else {
					candidatesWithoutTail.add(Integer.valueOf(i));
				}
			}
		}

		if (candidatesWithTail.size() == 1) {
			return candidatesWithTail.get(0);
		} else if (candidatesWithTail.size() > 1) {
			int indexWithLongestLength = candidatesWithTail.get(0);
			for (Integer idx : candidatesWithTail) {
				if (wordList.get(idx).length() > wordList.get(indexWithLongestLength).length()) {
					indexWithLongestLength = idx;
				}
			}
			return indexWithLongestLength;
		} else if (candidatesWithoutTail.size() == 1) {
			return candidatesWithoutTail.get(0);
		} else if (candidatesWithoutTail.size() > 1) {
			int indexWithLongestLength = candidatesWithoutTail.get(0);
			for (Integer idx : candidatesWithoutTail) {
				if (wordList.get(idx).length() > wordList.get(indexWithLongestLength).length()) {
					indexWithLongestLength = idx;
				}
			}
			return indexWithLongestLength;
		} else {
			return -1;
		}

	}

	
}
