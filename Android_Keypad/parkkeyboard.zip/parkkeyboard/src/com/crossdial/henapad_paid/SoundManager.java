﻿/*
 *  Modified by kuh on 2010/10.
 *  Modified by z.c. on 2010/10 - 2012/03.
 *  Copyright (C) 2010 Cross Dial Technologies. All rights reserved.
 * 
 */

package com.crossdial.henapad_paid;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

class SoundPlay extends Thread{  //Thread 클래스를 상속받는 클래스를 작성
	public SoundManager m_Sound = null;
	  public void run(){   //run() 메서드를 오버라이딩
		  if(m_Sound != null)
			  m_Sound._play(1);
	  }
	}

public class SoundManager extends SoundPool
{
	public static final int FAIL_LOAD = 0;
	public static final int SUCCESS_LOAD = 1;
	
	public static final int INVALID_ID = -1;

	private Context m_Context;
	private int[][] m_nSoundInfArr;
	private int m_nLoadSoundCount;
	private int m_nSoundMaxCount;
	private float m_fVolume;
	
	
	public SoundManager(Context p_Context, int p_nMaxStreams)
	{
		super(p_nMaxStreams, AudioManager.STREAM_MUSIC, 1);
		
		m_nSoundInfArr = new int[p_nMaxStreams][3];
		m_nLoadSoundCount = 0;
		m_nSoundMaxCount = p_nMaxStreams;
		m_fVolume = 0;
		m_Context = p_Context;
	}
	
	public int load(int p_nSoundIdx, int p_nSoundDataId)
	{
		
		if (m_nLoadSoundCount == m_nSoundMaxCount)
			return FAIL_LOAD;
		
		m_nSoundInfArr[m_nLoadSoundCount][0] = p_nSoundIdx;
		m_nSoundInfArr[m_nLoadSoundCount][1] = super.load(m_Context, p_nSoundDataId, 1);
		m_nLoadSoundCount = m_nLoadSoundCount + 1;
		
		return SUCCESS_LOAD; 
	}
	
	public void setVolume(int p_nVolumn)
	{
		float fVol = (float)p_nVolumn / 10.0F;
		
		for (int i = 0; i < m_nSoundMaxCount; i++)
			super.setVolume(m_nSoundInfArr[i][1], fVol, fVol);
			
		m_fVolume = fVol;
	}
	
	public void _play(int p_nSoundIdx)
	{
		super.play(getSoundId(p_nSoundIdx), m_fVolume, m_fVolume, 1, 0, 1);
	}
	public void play(int p_nSoundIdx)
	{
		SoundPlay snd = new SoundPlay();
		snd.m_Sound = this;
		snd.start();
	}
	
	private int getSoundId(int p_nSoundIdx)
	{
		int i;
		
		for (i = 0; i < m_nSoundMaxCount; i++)
		{
			if (m_nSoundInfArr[i][0] == p_nSoundIdx)
				return m_nSoundInfArr[i][1];
		}
		
		return INVALID_ID;
	}
}
